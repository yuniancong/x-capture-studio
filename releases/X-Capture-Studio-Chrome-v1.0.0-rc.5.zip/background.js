(function(){'use strict';const modules=[function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const urls_1 = __require(1);
const binary_1 = __require(2);
const probe_1 = __require(3);
const host_1 = __require(4);
const isX = (url) => { try {
    return /^(?:www\.|mobile\.)?(?:x\.com|twitter\.com)$/.test(new URL(url).hostname);
}
catch {
    return false;
} };
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !sender.tab?.id || !isX(sender.tab.url || sender.url || ''))
        return false;
    if (msg?.type === 'xc:asset') {
        if (typeof msg.url !== 'string' || !(0, urls_1.allowedAsset)(msg.url)) {
            respond({ ok: false, error: '资源地址不在允许列表。' });
            return false;
        }
        (0, host_1.nativeBytes)(msg.url).then(b => respond({ ok: true, data: (0, binary_1.base64)(b) })).catch(e => respond({ ok: false, error: e.message }));
        return true;
    }
    if (msg?.type === 'xc:probe') {
        const ids = Array.isArray(msg.ids) ? msg.ids.filter((id) => typeof id === 'string' && /^\d+$/.test(id)).slice(0, 250) : [];
        chrome.scripting.executeScript({ target: { tabId: sender.tab.id }, world: 'MAIN', func: probe_1.pageProbe, args: [ids] }).then((r) => respond({ ok: true, data: r[0]?.result || [] })).catch(() => respond({ ok: false, data: [] }));
        return true;
    }
    return false;
});

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sourceURL = sourceURL;
exports.postID = postID;
exports.safeLink = safeLink;
exports.allowedAsset = allowedAsset;
exports.plainText = plainText;
exports.contextText = contextText;
function sourceURL(value, base = 'https://x.com/') {
    try {
        const u = new URL(value, base);
        if (!['https:', 'http:'].includes(u.protocol))
            return;
        if (!/^(?:www\.|mobile\.)?(?:x\.com|twitter\.com)$/.test(u.hostname))
            return;
        const m = u.pathname.match(/^\/(?:([\w]+)\/status\/(\d+)|i\/article\/(\d+)|i\/web\/status\/(\d+))(?=\/|$)/);
        if (!m)
            return;
        return `https://x.com${m[3] ? '/i/article/' + m[3] : m[4] ? '/i/web/status/' + m[4] : '/' + m[1] + '/status/' + m[2]}`;
    }
    catch {
        return;
    }
}
function postID(url) { return url.match(/\/(?:status|article)\/(\d+)/)?.[1]; }
function safeLink(value, base = 'https://x.com/') {
    try {
        const u = new URL(value, base);
        return ['https:', 'http:'].includes(u.protocol) ? u.href : undefined;
    }
    catch {
        return;
    }
}
function allowedAsset(url) {
    try {
        const u = new URL(url);
        return u.protocol === 'https:' && !u.username && !u.password && (!u.port || u.port === '443') && (/^([a-z\d-]+\.)*twimg\.com$/.test(u.hostname) || u.href === 'https://raw.githubusercontent.com/notofonts/noto-cjk/Sans2.004/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf');
    }
    catch {
        return false;
    }
}
function plainText(p) { return p.blocks.map(b => b.kind === 'text' ? b.runs.map((r) => r.text).join('') : b.kind === 'media' ? `[${b.media.kind}: ${b.media.alt || '媒体'}]` : b.kind === 'embed' ? `[嵌入帖子]\n${plainText(b.post)}` : '').join('\n'); }
/** Copy the selected contextual record without pretending hidden fields were captured. */
function contextText(p, identity = true, sources = true, depth = 0) {
    if (depth > 5)
        return '[更深层引用未展开]';
    const out = [identity ? `${p.author.name} @${p.author.handle}` : '匿名用户'];
    if (p.title)
        out.push(p.title);
    if (p.published || p.displayTime)
        out.push(p.published || p.displayTime);
    out.push(plainText(p));
    if (p.quote)
        out.push('引用帖子：\n' + contextText(p.quote, identity, sources, depth + 1));
    if (p.poll)
        out.push('投票：\n' + p.poll.options.map((v) => v.text + (v.percent === undefined ? '' : ` ${v.percent}%`)).join('\n') + '\n' + (p.poll.summary || ''));
    if (p.note)
        out.push('读者补充背景：' + p.note);
    if (p.linkCard)
        out.push('链接卡片：' + p.linkCard.title + (sources ? '\n' + p.linkCard.url : ''));
    if (sources)
        out.push('来源：' + p.url);
    return out.filter(Boolean).join('\n');
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.utf8 = void 0;
exports.concat = concat;
exports.base64 = base64;
exports.unbase64 = unbase64;
exports.compress = compress;
exports.xml = xml;
exports.utf16Hex = utf16Hex;
const utf8 = (value) => new TextEncoder().encode(value);
exports.utf8 = utf8;
function concat(parts) { const out = new Uint8Array(parts.reduce((n, p) => n + p.byteLength, 0)); let o = 0; for (const p of parts) {
    out.set(p, o);
    o += p.byteLength;
} return out; }
function base64(bytes) { let value = ''; for (let i = 0; i < bytes.length; i += 24576)
    value += String.fromCharCode(...bytes.subarray(i, i + 24576)); return btoa(value); }
function unbase64(value) { const str = atob(value), out = new Uint8Array(str.length); for (let i = 0; i < str.length; i++)
    out[i] = str.charCodeAt(i); return out; }
async function compress(bytes) {
    if (typeof CompressionStream === 'undefined')
        return { data: bytes, filter: '' };
    try {
        const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate'));
        return { data: new Uint8Array(await new Response(stream).arrayBuffer()), filter: '/Filter /FlateDecode' };
    }
    catch {
        return { data: bytes, filter: '' };
    }
}
function xml(value) { return value.replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c])); }
function utf16Hex(value, bom = true) { let out = bom ? 'FEFF' : ''; for (let i = 0; i < value.length; i++)
    out += value.charCodeAt(i).toString(16).padStart(4, '0'); return out; }

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pageProbe = pageProbe;
/** Best-effort, read-only access to already-present page render data. No API calls,
 * cookie reads, credentials, hidden endpoint requests or account automation.
 * Function is self-contained because Chromium executes it in MAIN world. */
function pageProbe(ids, suppliedWindow) {
    const win = suppliedWindow || window, wanted = new Set(ids.slice(0, 250));
    const found = new Map();
    // Self-contained for MAIN-world execution. Read only variants already present
    // in the page; do not call an X endpoint or request video bytes.
    const publicMedia = (legacy, href) => {
        const valid = (s, video = false) => {
            if (typeof s !== 'string' || !/^https?:\/\//i.test(s) || /[\u0000-\u0020\u007f]/.test(s))
                return;
            try {
                const u = new URL(s);
                if (u.username || u.password || !/(^|\.)twimg\.com$/i.test(u.hostname))
                    return;
                if (video && !/\.(?:mp4|m4v|mov|webm|ogv|ogg|m3u8|mpd)$/i.test(u.pathname))
                    return;
                return u.href;
            }
            catch {
                return;
            }
        };
        const media = legacy?.extended_entities?.media;
        return (Array.isArray(media) ? media : []).slice(0, 8).filter((m) => m && valid(m.media_url_https)).map((m) => {
            const kind = m.type === 'photo' ? 'image' : m.type === 'animated_gif' ? 'gif' : 'video';
            const variants = Array.isArray(m.video_info?.variants) ? m.video_info.variants : [];
            const choices = variants.slice(0, 32).map((v) => ({ url: valid(v?.url, true), bitrate: Number(v?.bitrate) || 0 }))
                .filter((v) => v.url).sort((a, b) => {
                const rank = (u) => /\.mp4$/i.test(new URL(u).pathname) ? 2 : /\.(?:m3u8|mpd)$/i.test(new URL(u).pathname) ? 0 : 1;
                return rank(b.url) - rank(a.url) || b.bitrate - a.bitrate;
            });
            return { src: m.media_url_https, kind, alt: m.ext_alt_text || '引用帖媒体', href,
                ...(kind !== 'image' ? { posterUrl: m.media_url_https, sourceUrl: choices[0]?.url } : {}) };
        });
    };
    const publicQuote = (item, depth = 0) => {
        if (depth > 3 || !item || typeof item !== 'object')
            return;
        const q = item.tweet || item, legacy = q.legacy || {}, id = String(q.rest_id || legacy.id_str || '');
        if (!/^\d+$/.test(id))
            return;
        const user = q.core?.user_results?.result, userLegacy = user?.legacy || {}, name = user?.core?.name || userLegacy.name, handle = user?.core?.screen_name || userLegacy.screen_name;
        const fullText = q.note_tweet?.note_tweet_results?.result?.text || legacy.full_text;
        const result = { id, url: /^[A-Za-z0-9_]+$/.test(handle || '') ? `https://x.com/${handle}/status/${id}` : `https://x.com/i/web/status/${id}` };
        if (typeof name === 'string' && typeof handle === 'string')
            result.author = { name: name.slice(0, 200), handle: handle.slice(0, 40), avatar: user?.avatar?.image_url || userLegacy.profile_image_url_https, verified: !!(user?.is_blue_verified || userLegacy.verified) };
        if (typeof fullText === 'string')
            result.fullText = fullText.slice(0, 400000);
        const date = new Date(legacy.created_at);
        if (!isNaN(+date))
            result.published = date.toISOString();
        result.media = publicMedia(legacy, result.url);
        const nested = publicQuote(q.quoted_status_result?.result, depth + 1);
        if (nested)
            result.quote = nested;
        return result;
    };
    const nodes = [...win.document.querySelectorAll('article[data-testid="tweet"]')];
    for (const el of nodes) {
        const key = Object.keys(el).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactProps$'));
        if (!key)
            continue;
        const queue = [[el[key], 0]], seen = new WeakSet();
        let budget = 2200;
        while (queue.length && budget-- > 0) {
            const [obj, depth] = queue.shift();
            if (!obj || typeof obj !== 'object' || seen.has(obj))
                continue;
            seen.add(obj);
            let id;
            try {
                id = String(obj.rest_id || obj.id_str || obj.legacy?.id_str || '');
            }
            catch {
                continue;
            }
            if (id && wanted.has(id) && obj.legacy && (obj.legacy.full_text !== undefined || obj.note_tweet)) {
                const l = obj.legacy, n = obj.note_tweet?.note_tweet_results?.result;
                const text = typeof n?.text === 'string' ? n.text : typeof l.full_text === 'string' ? l.full_text : undefined;
                const data = { id, relationEvidence: 'data', media: publicMedia(l, `https://x.com/i/web/status/${id}`) };
                if (/^\d+$/.test(l.in_reply_to_status_id_str || ''))
                    data.parentId = l.in_reply_to_status_id_str;
                if (/^\d+$/.test(l.conversation_id_str || ''))
                    data.conversationId = l.conversation_id_str;
                if (text && text.length < 400000) {
                    // Expanded URLs and exact Unicode text are preferred over shortened t.co text.
                    const entities = n?.entity_set || l.entities || {};
                    let expanded = text;
                    for (const u of entities.urls || [])
                        if (u.url && u.expanded_url)
                            expanded = expanded.split(u.url).join(u.expanded_url);
                    data.fullText = expanded;
                }
                const q = publicQuote(obj.quoted_status_result?.result);
                if (q)
                    data.quote = q;
                if (/^\d+$/.test(l.quoted_status_id_str || ''))
                    data.quotedId = l.quoted_status_id_str;
                found.set(id, data);
            }
            if (depth >= 9)
                continue;
            let keys;
            try {
                keys = Object.keys(obj);
            }
            catch {
                continue;
            }
            for (const k of keys) {
                if (['return', 'stateNode', 'alternate', 'ownerDocument', 'parentNode', '_owner', 'ref', 'updateQueue', 'dependencies'].includes(k))
                    continue;
                if (/token|cookie|session|auth|password/i.test(k))
                    continue;
                try {
                    const val = obj[k];
                    if (val && typeof val === 'object' && !(val instanceof win.Node))
                        queue.push([val, depth + 1]);
                }
                catch { }
            }
        }
    }
    return [...found.values()];
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeBytes = nativeBytes;
exports.createHost = createHost;
const model_1 = __require(5);
const urls_1 = __require(1);
const binary_1 = __require(2);
const probe_1 = __require(3);
async function nativeBytes(url, signal) {
    const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 35000);
    const abort = () => ctrl.abort();
    signal?.addEventListener('abort', abort, { once: true });
    try {
        const r = await fetch(url, { signal: ctrl.signal, credentials: 'omit', referrerPolicy: 'no-referrer', redirect: 'error' });
        if (!r.ok)
            throw new Error(`资源请求失败 (${r.status})`);
        const max = url === model_1.FONT_URL ? 28 * 1024 * 1024 : 20 * 1024 * 1024;
        if (Number(r.headers.get('content-length')) > max)
            throw new Error('资源超过安全大小限制。');
        if (!r.body) {
            const b = new Uint8Array(await r.arrayBuffer());
            if (b.length > max)
                throw new Error('资源过大。');
            return b;
        }
        const reader = r.body.getReader(), chunks = [];
        let size = 0;
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            size += value.byteLength;
            if (size > max) {
                await reader.cancel();
                throw new Error('资源超过安全大小限制。');
            }
            chunks.push(value);
        }
        const bytes = new Uint8Array(size);
        let p = 0;
        for (const c of chunks) {
            bytes.set(c, p);
            p += c.length;
        }
        return bytes;
    }
    finally {
        clearTimeout(timer);
        signal?.removeEventListener('abort', abort);
    }
}
function gmRequest(url, signal) {
    return new Promise((resolve, reject) => {
        const modern = typeof GM !== 'undefined' ? GM : undefined;
        const send = typeof GM_xmlhttpRequest === 'function' ? GM_xmlhttpRequest : modern?.xmlHttpRequest;
        if (!send) {
            reject(new Error('脚本管理器未提供 GM_xmlhttpRequest。'));
            return;
        }
        let request, ended = false;
        const finish = (error, b) => { if (ended)
            return; ended = true; signal?.removeEventListener('abort', cancel); error ? reject(error) : resolve(b); };
        const cancel = () => { try {
            request?.abort();
        }
        catch { } finish(new DOMException('已取消', 'AbortError')); };
        if (signal?.aborted) {
            cancel();
            return;
        }
        signal?.addEventListener('abort', cancel, { once: true });
        request = send({ url, method: 'GET', anonymous: true, responseType: 'arraybuffer', timeout: 35000, onload: async (r) => {
                try {
                    if (r.status < 200 || r.status >= 300)
                        throw new Error(`资源请求失败 (${r.status})`);
                    let b;
                    if (r.response instanceof ArrayBuffer)
                        b = new Uint8Array(r.response);
                    else if (ArrayBuffer.isView(r.response))
                        b = new Uint8Array(r.response.buffer, r.response.byteOffset, r.response.byteLength);
                    else if (r.response instanceof Blob)
                        b = new Uint8Array(await r.response.arrayBuffer());
                    else
                        throw new Error('Stay 返回的二进制资源格式不受支持。');
                    if (b.length > (url === model_1.FONT_URL ? 28 : 20) * 1024 * 1024)
                        throw new Error('资源超过安全大小限制。');
                    finish(undefined, b);
                }
                catch (e) {
                    finish(e);
                }
            }, onerror: () => finish(new Error('资源加载失败，请检查网络或 Stay 的站点权限。')), ontimeout: () => finish(new Error('资源加载超时。')), onabort: cancel });
    });
}
/** A stalled mobile bridge must not prevent the studio from appearing. */
function storageRead(read, fallback) {
    return new Promise(resolve => {
        let done = false;
        const finish = (v) => { if (done)
            return; done = true; clearTimeout(timer); resolve(v); };
        const timer = setTimeout(() => finish(fallback), 2000);
        try {
            Promise.resolve(read()).then(v => finish(v === undefined ? fallback : v), () => finish(fallback));
        }
        catch {
            finish(fallback);
        }
    });
}
function createHost(kind) {
    if (kind === 'extension')
        return { kind,
            async getValue(key, fallback) { const v = await chrome.storage.local.get(key); return v[key] ?? fallback; },
            async setValue(key, value) { await chrome.storage.local.set({ [key]: value }); },
            async readBytes(url, signal) {
                if (!(0, urls_1.allowedAsset)(url))
                    throw new Error('资源域名不在允许列表。');
                if (signal?.aborted)
                    throw new DOMException('已取消', 'AbortError');
                const res = await chrome.runtime.sendMessage({ type: 'xc:asset', url });
                if (!res?.ok)
                    throw new Error(res?.error || '资源读取失败。');
                if (signal?.aborted)
                    throw new DOMException('已取消', 'AbortError');
                return (0, binary_1.unbase64)(res.data);
            },
            async probe(ids) { const r = await chrome.runtime.sendMessage({ type: 'xc:probe', ids }); return r?.data || []; } };
    return { kind,
        async getValue(key, fallback) { try {
            if (kind === 'stay') {
                if (typeof GM_getValue === 'function')
                    return await storageRead(() => GM_getValue(key, fallback), fallback);
                if (typeof GM !== 'undefined' && GM.getValue)
                    return await storageRead(() => GM.getValue(key, fallback), fallback);
            }
            const v = localStorage.getItem('xc:' + key);
            return v ? JSON.parse(v) : fallback;
        }
        catch {
            return fallback;
        } },
        async setValue(key, value) { if (kind === 'stay') {
            if (typeof GM_setValue === 'function') {
                await GM_setValue(key, value);
                return;
            }
            if (typeof GM !== 'undefined' && GM.setValue) {
                await GM.setValue(key, value);
                return;
            }
        } localStorage.setItem('xc:' + key, JSON.stringify(value)); },
        async readBytes(url, signal) { if (!(0, urls_1.allowedAsset)(url))
            throw new Error('资源域名不在允许列表。'); if (kind === 'stay') {
            try {
                return await gmRequest(url, signal);
            }
            catch (e) {
                if (signal?.aborted)
                    throw e;
                return nativeBytes(url, signal);
            }
        } return nativeBytes(url, signal); },
        async probe(ids) { return (0, probe_1.pageProbe)(ids, window); } };
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FONT_CACHE_KEY = exports.FONT_URL = exports.VERSION = void 0;
/** Captured facts are separate from selection, style and inferred relationships. */
exports.VERSION = '1.0.0-rc.5';
exports.FONT_URL = 'https://raw.githubusercontent.com/notofonts/noto-cjk/Sans2.004/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf';
exports.FONT_CACHE_KEY = 'noto-cjk-sc-Sans2.004';

}];const cache={};function requireModule(id){if(cache[id])return cache[id].exports;const m=cache[id]={exports:{}};modules[id](m,m.exports,requireModule);return m.exports;}return requireModule(0);})();
