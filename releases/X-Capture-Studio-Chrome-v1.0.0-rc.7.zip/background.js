(function(){'use strict';const modules=[function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const resource_network_1 = __require(1);
const resourceTasks = new Map();
const resourceRate = new Map();
const urls_1 = __require(3);
const binary_1 = __require(4);
const probe_1 = __require(5);
const host_1 = __require(6);
const isX = (url) => { try {
    return /^(?:www\.|mobile\.)?(?:x\.com|twitter\.com)$/.test(new URL(url).hostname);
}
catch {
    return false;
} };
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !sender.tab?.id || !isX(sender.tab.url || sender.url || ''))
        return false;
    if (msg?.type === 'xc:asset') {
        if (typeof msg.url !== 'string' || !(0, urls_1.allowedAsset)(msg.url)) {
            respond({ ok: false, error: '资源地址不在允许列表。' });
            return false;
        }
        (0, host_1.nativeBytes)(msg.url).then(b => respond({ ok: true, data: (0, binary_1.base64)(b) })).catch(e => respond({ ok: false, error: e.message }));
        return true;
    }
    if (msg?.type === 'xc:resource-cancel') {
        const key = sender.tab.id + ':' + msg.requestId;
        resourceTasks.get(key)?.abort();
        respond({ ok: true });
        return false;
    }
    if (msg?.type === 'xc:resource') {
        const r = (0, resource_network_1.safeResourceRequest)(msg.request);
        const id = typeof msg.requestId === 'string' && /^[\w-]{1,80}$/.test(msg.requestId) ? msg.requestId : undefined;
        if (!r || !id) {
            respond({ ok: false });
            return false;
        }
        const tab = sender.tab.id, now = Date.now(), limit = resourceRate.get(tab);
        if (limit && now - limit.at < 60000 && limit.count >= 64) {
            respond({ ok: false });
            return false;
        }
        if (resourceTasks.size >= 8) {
            respond({ ok: false });
            return false;
        }
        if (resourceRate.size > 200)
            resourceRate.clear();
        resourceRate.set(tab, limit && now - limit.at < 60000 ? { ...limit, count: limit.count + 1 } : { at: now, count: 1 });
        const key = tab + ':' + id, ctrl = new AbortController();
        resourceTasks.set(key, ctrl);
        (0, resource_network_1.nativeResource)(r, ctrl.signal).then(response => { const { bytes, ...meta } = response; respond({ ok: true, response: meta, data: (0, binary_1.base64)(bytes) }); }).catch(() => respond({ ok: false })).finally(() => resourceTasks.delete(key));
        return true;
    }
    if (msg?.type === 'xc:probe') {
        const ids = Array.isArray(msg.ids) ? msg.ids.filter((id) => typeof id === 'string' && /^\d+$/.test(id)).slice(0, 250) : [];
        chrome.scripting.executeScript({ target: { tabId: sender.tab.id }, world: 'MAIN', func: probe_1.pageProbe, args: [ids] }).then((r) => respond({ ok: true, data: r[0]?.result || [] })).catch(() => respond({ ok: false, data: [] }));
        return true;
    }
    return false;
});

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.safeResourceRequest = safeResourceRequest;
exports.nativeResource = nativeResource;
exports.decodeImageDimensions = decodeImageDimensions;
const resources_1 = __require(2);
function safeResourceRequest(raw) {
    if (!raw || !(0, resources_1.fetchableResource)(raw.url) || !['image', 'manifest', 'headers'].includes(raw.purpose))
        return;
    const limit = raw.purpose === 'image' ? 8 * 1024 * 1024 : raw.purpose === 'manifest' ? 524288 : 65536;
    return { url: raw.url, purpose: raw.purpose, maxBytes: Math.max(1, Math.min(limit, Number(raw.maxBytes) || limit)), timeoutMs: Math.max(500, Math.min(10000, Number(raw.timeoutMs) || 6000)) };
}
/** No GM bridge is used for new resource validation: older Stay bridges do not
 * document redirect rejection reliably. Native fetch fails closed on CORS/redirect.
 * DOM-discovered addresses remain available even when validation is impossible. */
async function nativeResource(raw, signal) {
    const request = safeResourceRequest(raw);
    const empty = new Uint8Array();
    if (!request)
        return { status: 0, url: '', mime: '', bytes: empty, problem: 'domain-blocked' };
    const ctrl = new AbortController();
    let timed = false;
    const stop = () => ctrl.abort();
    if (signal?.aborted)
        stop();
    else
        signal?.addEventListener('abort', stop, { once: true });
    const timer = setTimeout(() => { timed = true; ctrl.abort(); }, request.timeoutMs);
    const requestInit = { credentials: 'omit', referrerPolicy: 'no-referrer', redirect: 'error', cache: 'no-store', signal: ctrl.signal };
    try {
        let response = await fetch(request.url, { ...requestInit, method: request.purpose === 'headers' ? 'HEAD' : 'GET' });
        // A rejected HEAD is not proof a GET resource is unavailable. Bound the fallback.
        if (request.purpose === 'headers' && [405, 501].includes(response.status))
            response = await fetch(request.url, { ...requestInit, method: 'GET', headers: { Range: 'bytes=0-65535' } });
        if (response.redirected || response.url && response.url !== request.url) {
            await response.body?.cancel();
            return { status: response.status, url: request.url, mime: '', bytes: empty, problem: 'redirect-blocked' };
        }
        const mime = response.headers.get('content-type') || '', size = Number(response.headers.get('content-length'));
        if (!response.ok) {
            await response.body?.cancel();
            return { status: response.status, url: request.url, mime, bytes: empty, problem: response.status === 404 || response.status === 410 ? 'not-found' : response.status === 401 || response.status === 403 ? 'forbidden' : response.status === 429 ? 'rate-limit' : 'http-error' };
        }
        if (request.purpose === 'headers') {
            await response.body?.cancel();
            return { status: response.status, url: request.url, mime, bytes: empty };
        }
        if (size > request.maxBytes) {
            await response.body?.cancel();
            return { status: response.status, url: request.url, mime, bytes: empty, problem: 'too-large' };
        }
        if (!response.body) {
            return { status: response.status, url: request.url, mime, bytes: empty, problem: 'unsupported' };
        }
        const reader = response.body.getReader(), chunks = [];
        let received = 0;
        while (true) {
            const { value, done } = await reader.read();
            if (done)
                break;
            received += value.length;
            if (received > request.maxBytes) {
                await reader.cancel();
                return { status: response.status, url: request.url, mime, bytes: empty, problem: 'too-large' };
            }
            chunks.push(value);
        }
        const bytes = new Uint8Array(received);
        let offset = 0;
        for (const part of chunks) {
            bytes.set(part, offset);
            offset += part.length;
        }
        return { status: response.status, url: request.url, mime, bytes };
    }
    catch {
        return { status: 0, url: request.url, mime: '', bytes: empty, problem: timed ? 'timeout' : signal?.aborted ? 'cancelled' : 'network-or-cors' };
    }
    finally {
        clearTimeout(timer);
        signal?.removeEventListener('abort', stop);
    }
}
async function decodeImageDimensions(bytes, mime) {
    const a = bytes;
    let type = '';
    if (a[0] === 0xff && a[1] === 0xd8)
        type = 'image/jpeg';
    else if (a.length > 24 && a[0] === 137 && a[1] === 80 && a[2] === 78 && a[3] === 71)
        type = 'image/png';
    else if (a.length > 10 && String.fromCharCode(...a.slice(0, 3)) === 'GIF')
        type = 'image/gif';
    else if (a.length > 16 && String.fromCharCode(...a.slice(0, 4)) === 'RIFF' && String.fromCharCode(...a.slice(8, 12)) === 'WEBP')
        type = 'image/webp';
    else if (a.length > 16 && String.fromCharCode(...a.slice(4, 8)) === 'ftyp' && /avif|avis/.test(String.fromCharCode(...a.slice(8, 32))))
        type = 'image/avif';
    if (!type)
        throw new Error('Not a supported bitmap');
    const blob = new Blob([bytes], { type });
    const check = (w, h) => { if (!w || !h || w * h > 80000000)
        throw new Error('Image pixel budget'); return { width: w, height: h }; };
    // Do not instantiate an enormous bitmap if its header already reveals its dimensions.
    if (type === 'image/png') {
        const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        check(v.getUint32(16), v.getUint32(20));
    }
    if (type === 'image/gif')
        check(a[6] + a[7] * 256, a[8] + a[9] * 256);
    if (type === 'image/jpeg') {
        let offset = 2;
        while (offset + 8 < a.length) {
            if (a[offset] !== 255) {
                offset++;
                continue;
            }
            while (a[offset] === 255)
                offset++;
            const marker = a[offset++];
            if (marker === 217 || marker === 218)
                break;
            if (marker === 1 || marker >= 208 && marker <= 215)
                continue;
            const length = a[offset] * 256 + a[offset + 1];
            if (length < 2 || offset + length > a.length)
                break;
            if ([192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207].includes(marker)) {
                check(a[offset + 5] * 256 + a[offset + 6], a[offset + 3] * 256 + a[offset + 4]);
                break;
            }
            offset += length;
        }
    }
    if (type === 'image/webp') {
        const v = new DataView(a.buffer, a.byteOffset, a.byteLength);
        let at = 12;
        while (at + 8 <= a.length) {
            const kind = String.fromCharCode(...a.slice(at, at + 4)), length = v.getUint32(at + 4, true), start = at + 8;
            if (start + length > a.length)
                break;
            if (kind === 'VP8X' && length >= 10)
                check(1 + a[start + 4] + 256 * a[start + 5] + 65536 * a[start + 6], 1 + a[start + 7] + 256 * a[start + 8] + 65536 * a[start + 9]);
            if (kind === 'VP8L' && length >= 5 && a[start] === 47) {
                const bits = v.getUint32(start + 1, true);
                check(1 + (bits & 16383), 1 + ((bits >>> 14) & 16383));
            }
            if (kind === 'VP8 ' && length >= 10 && a[start + 3] === 157 && a[start + 4] === 1 && a[start + 5] === 42)
                check(v.getUint16(start + 6, true) & 16383, v.getUint16(start + 8, true) & 16383);
            at = start + length + (length % 2);
        }
    }
    if (type === 'image/avif') {
        // ispe dimensions occur inside a bounded ISO-BMFF property box. Inspect only valid box sizes.
        const v = new DataView(a.buffer, a.byteOffset, a.byteLength);
        for (let at = 4; at + 16 < a.length; at++)
            if (a[at] === 105 && a[at + 1] === 115 && a[at + 2] === 112 && a[at + 3] === 101) {
                const size = v.getUint32(at - 4);
                if (size >= 20 && at - 4 + size <= a.length)
                    check(v.getUint32(at + 8), v.getUint32(at + 12));
            }
    }
    if (typeof createImageBitmap === 'function') {
        let bitmap;
        try {
            bitmap = await createImageBitmap(blob);
            return check(bitmap.width, bitmap.height);
        }
        finally {
            bitmap?.close();
        }
    }
    const url = URL.createObjectURL(blob);
    try {
        return await new Promise((resolve, reject) => { const im = new Image(), timer = setTimeout(() => { im.src = ''; reject(new Error('Image decode timeout')); }, 7000); im.onload = () => { clearTimeout(timer); try {
            resolve(check(im.naturalWidth, im.naturalHeight));
        }
        catch (e) {
            reject(e);
        } }; im.onerror = () => { clearTimeout(timer); reject(new Error('Image decode failed')); }; im.src = url; });
    }
    finally {
        URL.revokeObjectURL(url);
    }
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resourceURL = resourceURL;
exports.sensitiveURL = sensitiveURL;
exports.fetchableResource = fetchableResource;
exports.mediaFormat = mediaFormat;
exports.classifyResource = classifyResource;
exports.variant = variant;
exports.variantKey = variantKey;
exports.mergeVariants = mergeVariants;
exports.mergeTracks = mergeTracks;
exports.sameMediaKey = sameMediaKey;
exports.existingVariants = existingVariants;
exports.mergeMediaResources = mergeMediaResources;
exports.imageCandidates = imageCandidates;
exports.preferredImage = preferredImage;
exports.recommendedVariants = recommendedVariants;
exports.visitMedia = visitMedia;
function resourceURL(value, base) {
    if (typeof value !== 'string' || value.length > 12000 || /[\u0000-\u0020\u007f\\]/.test(value))
        return;
    try {
        const u = new URL(value, base);
        if (!['https:', 'http:'].includes(u.protocol) || u.username || u.password)
            return;
        if (!u.hostname || /^(?:localhost|.*\.localhost|.*\.local|.*\.internal|.*\.lan)$/.test(u.hostname) || u.hostname.includes(':') || /^\d+(?:\.\d+){0,3}$/.test(u.hostname))
            return;
        return u.href;
    }
    catch {
        return;
    }
}
function sensitiveURL(value) {
    try {
        const u = new URL(value);
        const keys = [...u.searchParams.keys()];
        return keys.some(k => /(?:token|signature|credential|authorization|password|secret|^sig$|^key$|api.?key|^policy$|^expires?$|^x-amz-|^x-goog-|key-pair-id|^jwt$|^auth$|^hdnea$|^hdnts$)/i.test(k)) ||
            /(?:^|[?&#])(?:access_token|token|sig|key)=/i.test(u.hash) || /\/(?:token|signature|auth)\/[^/]+/i.test(u.pathname);
    }
    catch {
        return false;
    }
}
/** Network verification is deliberately narrower than link discovery. No new host permissions. */
function fetchableResource(value) {
    const s = resourceURL(value);
    if (!s)
        return false;
    const u = new URL(s);
    return u.protocol === 'https:' && !u.port && ['pbs.twimg.com', 'video.twimg.com', 'abs.twimg.com'].includes(u.hostname);
}
function mediaFormat(url, mime = '') {
    const type = mime.split(';')[0].trim().toLowerCase();
    if (/(?:vnd\.apple\.mpegurl|x-mpegurl)/.test(type))
        return 'hls';
    if (type === 'application/dash+xml')
        return 'dash';
    if (type === 'application/ttml+xml')
        return 'ttml';
    if (type === 'text/vtt')
        return 'vtt';
    if (/subrip/.test(type))
        return 'srt';
    if (type === 'video/mp2t')
        return 'ts';
    if (/vmap|vast/.test(type))
        return 'vmap';
    const m = { 'video/mp4': 'mp4', 'video/x-m4v': 'm4v', 'video/quicktime': 'mov', 'video/webm': 'webm', 'video/ogg': 'ogv', 'audio/mp4': 'm4a', 'audio/mpeg': 'mp3', 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif' };
    if (m[type])
        return m[type];
    try {
        const u = new URL(url), ext = u.pathname.match(/\.([a-z0-9]+)(?::(?:small|large|orig|thumb|medium|\d+x\d+))?$/i)?.[1]?.toLowerCase();
        const fmt = u.hostname === 'pbs.twimg.com' ? u.searchParams.get('format') : undefined;
        return (fmt || ext || '').replace(/^m3u8$/, 'hls').replace(/^mpd$/, 'dash').replace(/^jpeg$/, 'jpg');
    }
    catch {
        return '';
    }
}
function classifyResource(url, mime = '', hint) {
    if (hint === 'segment' || hint === 'poster' || hint === 'page')
        return hint;
    const f = mediaFormat(url, mime), type = mime.toLowerCase();
    // Provenance beats extension: an MP4 may be an initialization or media segment.
    if (['ts', 'm4s', 'cmfv', 'cmfa'].includes(f) || (/\/(?:segments?|chunks?|seg)\/|\/(?:init|initialization|segment[-_]\d+)(?:\.|\/)/i.test(new URL(url).pathname) && ['mp4', 'm4v'].includes(f)))
        return 'segment';
    if (f === 'hls')
        return 'hls';
    if (f === 'dash')
        return 'dash';
    if (f === 'vmap')
        return 'vmap';
    if (['vtt', 'srt', 'ttml', 'dfxp'].includes(f))
        return 'subtitle';
    if (['jpg', 'png', 'gif', 'webp', 'avif'].includes(f) || type.startsWith('image/'))
        return 'image';
    if (type.startsWith('audio/') || ['aac', 'm4a', 'mp3', 'opus'].includes(f))
        return 'audio';
    if (['mp4', 'm4v', 'mov', 'webm', 'ogv', 'ogg'].includes(f) || type.startsWith('video/'))
        return 'file';
    return hint || 'unknown';
}
const positive = (v) => typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : undefined;
const word = (s, max = 180) => typeof s === 'string' ? s.replace(/[\u0000-\u001f\u007f]/g, '').slice(0, max) : undefined;
/** Whitelist fields from a page or manifest. Never copy arbitrary objects into exportable data. */
function variant(value, source = 'dom', hint, base) {
    const v = typeof value === 'string' ? { url: value } : value;
    if (!v || typeof v !== 'object')
        return;
    const url = resourceURL(v.url, base);
    if (!url)
        return;
    const mime = word(v.mime || v.content_type, 100), kind = classifyResource(url, mime, hint || v.kind);
    if (!['image', 'file', 'hls', 'dash', 'audio', 'subtitle', 'poster', 'segment', 'vmap', 'page', 'unknown'].includes(kind))
        return;
    const out = { url, kind, format: mediaFormat(url, mime) || word(v.format, 32), source, mime, state: 'observed', sensitive: sensitiveURL(url) || v.sensitive === true };
    for (const k of ['width', 'height', 'bitrate', 'averageBitrate', 'frameRate', 'descriptorWidth', 'descriptorDensity']) {
        const n = positive(v[k] ?? (k === 'bitrate' ? v.bit_rate : undefined));
        if (n !== undefined && n < 1e12)
            out[k] = n;
    }
    for (const k of ['codecs', 'language', 'name', 'parentUrl', 'audioGroup', 'subtitleGroup', 'captionGroup', 'periodId', 'adaptationId', 'representationId', 'discoveredAt', 'checkedAt']) {
        const t = word(v[k], k === 'parentUrl' ? 12000 : 180);
        if (t)
            out[k] = t;
    }
    if (['observed', 'candidate', 'verified', 'unverified', 'unavailable', 'blocked'].includes(v.state))
        out.state = v.state;
    if (['video', 'audio', 'subtitle', 'iframe'].includes(v.role))
        out.role = v.role;
    if (['master', 'media'].includes(v.playlist))
        out.playlist = v.playlist;
    if (v.segmented !== undefined)
        out.segmented = !!v.segmented;
    for (const k of ['encrypted', 'drm', 'live'])
        if (typeof v[k] === 'boolean')
            out[k] = v[k];
    if (v.verifiedBy && ['image-decode', 'manifest-parse', 'headers'].includes(v.verifiedBy))
        out.verifiedBy = v.verifiedBy;
    if (typeof v.httpStatus === 'number')
        out.httpStatus = v.httpStatus;
    if (typeof v.problem === 'string')
        out.problem = v.problem;
    return out;
}
function variantKey(v) { return [v.kind, v.url, v.role || '', v.periodId || '', v.representationId || '', v.audioGroup || '', v.subtitleGroup || ''].join('\u001f'); }
function mergeVariants(...arrays) {
    const map = new Map();
    for (const arr of arrays)
        for (const raw of (arr || []).slice(0, 512)) {
            const v = variant(raw, raw.source, raw.kind);
            if (!v)
                continue;
            const key = variantKey(v), a = map.get(key);
            if (!a) {
                if (map.size < 512)
                    map.set(key, v);
                continue;
            }
            const out = { ...a };
            for (const [k, val] of Object.entries(v))
                if (val !== undefined)
                    out[k] = val;
            // A fresh scan cannot erase a network check. A later explicit check CAN supersede it.
            if (!v.checkedAt && a.checkedAt) {
                out.state = a.state;
                out.checkedAt = a.checkedAt;
                out.problem = a.problem;
                out.verifiedBy = a.verifiedBy;
                out.width = a.width || v.width;
                out.height = a.height || v.height;
            }
            else if (a.state === 'observed' && v.state === 'candidate')
                out.state = 'observed';
            if (a.sensitive || v.sensitive)
                out.sensitive = true;
            map.set(key, out);
        }
    return [...map.values()];
}
function mergeTracks(...arrays) {
    const map = new Map();
    for (const arr of arrays)
        for (const t of (arr || []).slice(0, 128)) {
            if (!t || !['audio', 'subtitles', 'captions', 'descriptions'].includes(t.kind))
                continue;
            const url = resourceURL(t.url), manifestUrl = resourceURL(t.manifestUrl);
            const key = [t.kind, url || '', t.language || '', t.groupId || '', t.periodId || '', t.representationId || '', t.inBand ? 'in-band' : '', !url ? t.id : ''].join('|');
            const clean = { id: word(t.id, 256) || key, kind: t.kind, url, manifestUrl, state: t.state || 'observed', source: t.source || 'track' };
            for (const k of ['language', 'label', 'format', 'mime', 'codecs', 'groupId', 'periodId', 'adaptationId', 'representationId'])
                clean[k] = word(t[k]);
            for (const k of ['inBand', 'default', 'forced', 'autoSelect', 'encrypted', 'segmented'])
                if (typeof t[k] === 'boolean')
                    clean[k] = t[k];
            clean.sensitive = t.sensitive || !!url && sensitiveURL(url) || !!manifestUrl && sensitiveURL(manifestUrl);
            if (map.size < 128 || map.has(key))
                map.set(key, { ...map.get(key), ...clean });
        }
    return [...map.values()];
}
function sameMediaKey(m) {
    if (m.mediaId)
        return 'id:' + m.mediaId;
    const u = resourceURL(m.posterUrl) || resourceURL(m.src);
    if (!u)
        return;
    const a = new URL(u);
    // Only documented X image renditions share identity across format/size requests.
    if (a.hostname === 'pbs.twimg.com' && /^\/media\/[A-Za-z0-9_-]+/.test(a.pathname))
        return a.hostname + a.pathname.replace(/:(?:thumb|small|medium|large|orig|\d+x\d+)$/i, '').replace(/\.(?:jpe?g|png|webp|gif)$/i, '');
    return u;
}
function existingVariants(m) {
    const a = [];
    for (const url of m.kind === 'image' ? [m.src, m.sourceUrl] : [m.sourceUrl, m.href]) {
        const v = variant(url, 'legacy', m.kind === 'image' ? 'image' : undefined);
        if (v && ((m.kind === 'image' && v.kind === 'image') || (m.kind !== 'image' && ['file', 'hls', 'dash', 'vmap', 'audio'].includes(v.kind))))
            a.push(v);
    }
    return mergeVariants(a, m.variants);
}
function mergeMediaResources(target, incoming) {
    if (target.ownerId && incoming.ownerId && target.ownerId !== incoming.ownerId)
        return;
    if (target.mediaId && incoming.mediaId && target.mediaId !== incoming.mediaId)
        return;
    const a = existingVariants(target), b = existingVariants({ ...target, variants: [], sourceUrl: undefined, ...incoming });
    target.variants = mergeVariants(a, b);
    target.tracks = mergeTracks(target.tracks, incoming.tracks);
    target.mediaId = target.mediaId || incoming.mediaId;
    target.ownerId = target.ownerId || incoming.ownerId;
    const info = new Map((target.manifests || []).map(x => [x.url, x]));
    for (const m of incoming.manifests || [])
        info.set(m.url, m);
    target.manifests = [...info.values()].slice(0, 64);
    target.resourceNotes = [...new Set([...(target.resourceNotes || []), ...(incoming.resourceNotes || [])])].slice(0, 40);
    if (!target.selectedImageUrl && incoming.selectedImageUrl)
        target.selectedImageUrl = incoming.selectedImageUrl;
}
/** Candidate rank is a request strategy, never an assertion about existing originals. */
function imageCandidates(m) {
    const observed = existingVariants(m).filter(v => v.kind === 'image').sort((a, b) => Number(b.source === 'page-data') - Number(a.source === 'page-data'));
    const generated = [];
    for (const v of observed) {
        const u = new URL(v.url);
        if (u.hostname !== 'pbs.twimg.com' || sensitiveURL(v.url) || u.port)
            continue;
        const match = u.pathname.match(/^\/media\/([A-Za-z0-9_-]+)(?:\.(jpe?g|png|webp|gif))?(?::(?:thumb|small|medium|large|orig|\d+x\d+))?$/i);
        if (!match)
            continue;
        const fmt = (u.searchParams.get('format') || match[2] || '').toLowerCase();
        if (!['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(fmt))
            continue;
        for (const size of fmt === 'webp' ? ['4096x4096', 'large', 'medium'] : ['orig', '4096x4096', 'large', 'medium']) {
            const c = new URL(v.url);
            c.protocol = 'https:';
            c.pathname = '/media/' + match[1];
            c.searchParams.set('format', fmt === 'jpeg' ? 'jpg' : fmt);
            c.searchParams.set('name', size);
            c.hash = '';
            const x = variant(c.href, 'image-rule', 'image');
            x.state = 'candidate';
            x.name = size;
            generated.push(x);
        }
    }
    const merged = mergeVariants(generated, observed);
    const rank = (v) => { const name = new URL(v.url).searchParams.get('name') || v.name; return name === 'orig' ? 1e9 : name === '4096x4096' ? 4096 : name === 'large' ? 2048 : name === 'medium' ? 1200 : (v.width || v.descriptorWidth || (v.descriptorDensity || 0) * 1000); };
    return merged.sort((a, b) => rank(b) - rank(a)).slice(0, 24);
}
function preferredImage(m) {
    const variants = existingVariants(m).filter(v => v.kind === 'image');
    const selected = variants.find(v => v.url === m.selectedImageUrl && !['unavailable', 'blocked'].includes(v.state) && (v.source !== 'image-rule' || v.state === 'verified'));
    if (selected)
        return selected;
    const known = variants.filter(v => v.state === 'verified' && v.verifiedBy === 'image-decode');
    if (known.length)
        return known.sort((a, b) => (b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0))[0];
    // Do not discard an observed URL solely because the checking environment has CORS/network limits.
    const ok = variants.filter(v => v.source !== 'image-rule' && v.state !== 'candidate' && v.state !== 'unavailable');
    return ok.sort((a, b) => (b.width || b.descriptorWidth || 0) - (a.width || a.descriptorWidth || 0) || ((b.descriptorDensity || 0) - (a.descriptorDensity || 0)) || Number(b.source === 'page-data') - Number(a.source === 'page-data'))[0] || variants.find(v => v.source !== 'image-rule');
}
function recommendedVariants(m, all = false) {
    const a = existingVariants(m).filter(v => !['candidate', 'unavailable'].includes(v.state) && ['file', 'hls', 'dash', 'audio', 'vmap'].includes(v.kind) && v.role !== 'iframe' && v.role !== 'subtitle' && v.role !== 'audio');
    if (all)
        return a;
    const out = [];
    for (const kind of ['file', 'hls', 'dash', 'vmap']) {
        const group = a.filter(v => v.kind === kind);
        group.sort((a, b) => Number(b.playlist === 'master' || (!b.parentUrl && !b.representationId)) - Number(a.playlist === 'master' || (!a.parentUrl && !a.representationId)) ||
            ((b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0)) || ((a.codecs || '') === (b.codecs || '') ? (b.bitrate || 0) - (a.bitrate || 0) : 0));
        if (group[0])
            out.push(group[0]);
    }
    return out;
}
function visitMedia(capture, selected, fn, quotes = true) {
    const seen = new Set();
    let budget = 2000;
    const visit = (p, depth) => {
        if (depth > 8 || seen.has(p) || budget-- <= 0)
            return;
        seen.add(p);
        let i = 0;
        for (const b of p.blocks) {
            if (b.kind === 'media') {
                b.media.ownerId = p.id;
                b.media.scopeId = `${p.id}:${b.media.mediaRole || 'body'}:${sameMediaKey(b.media) || i}`;
                fn(b.media, p);
                i++;
            }
            else if (b.kind === 'embed' && quotes)
                visit(b.post, depth + 1);
        }
        if (p.linkCard?.media) {
            const m = p.linkCard.media;
            m.ownerId = p.id;
            m.scopeId = `${p.id}:card:${sameMediaKey(m) || 'visible'}`;
            fn(m, p);
        }
        if (p.quote && quotes)
            visit(p.quote, depth + 1);
    };
    for (const p of capture.posts)
        if (selected.has(p.id))
            visit(p, 0);
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sourceURL = sourceURL;
exports.postID = postID;
exports.safeLink = safeLink;
exports.allowedAsset = allowedAsset;
exports.plainText = plainText;
exports.contextText = contextText;
function sourceURL(value, base = 'https://x.com/') {
    try {
        const u = new URL(value, base);
        if (!['https:', 'http:'].includes(u.protocol))
            return;
        if (!/^(?:www\.|mobile\.)?(?:x\.com|twitter\.com)$/.test(u.hostname))
            return;
        const m = u.pathname.match(/^\/(?:([\w]+)\/status\/(\d+)|i\/article\/(\d+)|i\/web\/status\/(\d+))(?=\/|$)/);
        if (!m)
            return;
        return `https://x.com${m[3] ? '/i/article/' + m[3] : m[4] ? '/i/web/status/' + m[4] : '/' + m[1] + '/status/' + m[2]}`;
    }
    catch {
        return;
    }
}
function postID(url) { return url.match(/\/(?:status|article)\/(\d+)/)?.[1]; }
function safeLink(value, base = 'https://x.com/') {
    try {
        const u = new URL(value, base);
        return ['https:', 'http:'].includes(u.protocol) ? u.href : undefined;
    }
    catch {
        return;
    }
}
function allowedAsset(url) {
    try {
        const u = new URL(url);
        return u.protocol === 'https:' && !u.username && !u.password && (!u.port || u.port === '443') && (/^([a-z\d-]+\.)*twimg\.com$/.test(u.hostname) || u.href === 'https://raw.githubusercontent.com/notofonts/noto-cjk/Sans2.004/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf');
    }
    catch {
        return false;
    }
}
function plainText(p) { return p.blocks.map(b => b.kind === 'text' ? b.runs.map((r) => r.text).join('') : b.kind === 'media' ? `[${b.media.kind}: ${b.media.alt || '媒体'}]` : b.kind === 'embed' ? `[嵌入帖子]\n${plainText(b.post)}` : '').join('\n'); }
/** Copy the selected contextual record without pretending hidden fields were captured. */
function contextText(p, identity = true, sources = true, depth = 0) {
    if (depth > 5)
        return '[更深层引用未展开]';
    const out = [identity ? `${p.author.name} @${p.author.handle}` : '匿名用户'];
    if (p.title)
        out.push(p.title);
    if (p.published || p.displayTime)
        out.push(p.published || p.displayTime);
    out.push(plainText(p));
    if (p.quote)
        out.push('引用帖子：\n' + contextText(p.quote, identity, sources, depth + 1));
    if (p.poll)
        out.push('投票：\n' + p.poll.options.map((v) => v.text + (v.percent === undefined ? '' : ` ${v.percent}%`)).join('\n') + '\n' + (p.poll.summary || ''));
    if (p.note)
        out.push('读者补充背景：' + p.note);
    if (p.linkCard)
        out.push('链接卡片：' + p.linkCard.title + (sources ? '\n' + p.linkCard.url : ''));
    if (sources)
        out.push('来源：' + p.url);
    return out.filter(Boolean).join('\n');
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.utf8 = void 0;
exports.concat = concat;
exports.base64 = base64;
exports.unbase64 = unbase64;
exports.compress = compress;
exports.xml = xml;
exports.utf16Hex = utf16Hex;
const utf8 = (value) => new TextEncoder().encode(value);
exports.utf8 = utf8;
function concat(parts) { const out = new Uint8Array(parts.reduce((n, p) => n + p.byteLength, 0)); let o = 0; for (const p of parts) {
    out.set(p, o);
    o += p.byteLength;
} return out; }
function base64(bytes) { let value = ''; for (let i = 0; i < bytes.length; i += 24576)
    value += String.fromCharCode(...bytes.subarray(i, i + 24576)); return btoa(value); }
function unbase64(value) { const str = atob(value), out = new Uint8Array(str.length); for (let i = 0; i < str.length; i++)
    out[i] = str.charCodeAt(i); return out; }
async function compress(bytes) {
    if (typeof CompressionStream === 'undefined')
        return { data: bytes, filter: '' };
    try {
        const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate'));
        return { data: new Uint8Array(await new Response(stream).arrayBuffer()), filter: '/Filter /FlateDecode' };
    }
    catch {
        return { data: bytes, filter: '' };
    }
}
function xml(value) { return value.replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c])); }
function utf16Hex(value, bom = true) { let out = bom ? 'FEFF' : ''; for (let i = 0; i < value.length; i++)
    out += value.charCodeAt(i).toString(16).padStart(4, '0'); return out; }

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pageProbe = pageProbe;
/** Best-effort, read-only access to already-present page render data. No API calls,
 * cookie reads, credentials, hidden endpoint requests or account automation.
 * Function is self-contained because Chromium executes it in MAIN world. */
function pageProbe(ids, suppliedWindow) {
    const win = suppliedWindow || window, wanted = new Set(ids.slice(0, 250));
    const found = new Map();
    // Self-contained for MAIN-world execution. Read only variants already present
    // in the page; do not call an X endpoint or request video bytes.
    const publicMedia = (subject, href) => {
        const valid = (s) => {
            if (typeof s !== 'string' || s.length > 12000 || !/^https?:\/\//i.test(s) || /[\u0000-\u0020\u007f]/.test(s))
                return;
            try {
                const u = new URL(s);
                if (u.username || u.password || u.port || !/(^|\.)twimg\.com$/i.test(u.hostname))
                    return;
                return u.href;
            }
            catch {
                return;
            }
        };
        const finite = (v) => Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : undefined;
        const string = (v) => typeof v === 'string' ? v.replace(/[\u0000-\u001f]/g, '').slice(0, 240) : undefined;
        const legacy = subject?.legacy || subject;
        let raw = legacy?.extended_entities?.media || subject?.media_entities || subject?.article?.media_entities || subject?.article_results?.result?.media_entities || [];
        // API-v2-shaped data is accepted only when explicitly attached to this same object.
        if (!raw.length && Array.isArray(subject?.attachments?.media_keys) && Array.isArray(subject?.includes?.media))
            raw = subject.includes.media.filter((m) => subject.attachments.media_keys.includes(m.media_key));
        if (!Array.isArray(raw))
            raw = [];
        return raw.slice(0, 64).filter((m) => m && typeof m === 'object').map((m, index) => {
            const info = m.media_info || m, video = info.video_info || m.video_info || info;
            const type = info.type || m.type || info.__typename;
            const kind = type === 'photo' || type === 'image' || /Image/.test(type) ? 'image' : type === 'animated_gif' ? 'gif' : 'video';
            const src = valid(m.media_url_https) || valid(info.original_img_url) || valid(info.media_url_https) || valid(info.preview_image_url) || valid(m.preview_image_url) || (kind === 'image' ? valid(info.url) : undefined) || '';
            const width = finite(info.original_info?.width || info.width), height = finite(info.original_info?.height || info.height);
            const variants = (Array.isArray(video.variants) ? video.variants : Array.isArray(info.variants) ? info.variants : []).slice(0, 128).map((v) => {
                const url = valid(v?.url);
                if (!url)
                    return;
                const mime = string(v.content_type || v.mime_type || v.mime);
                const path = new URL(url).pathname, ext = path.match(/\.(\w+)$/)?.[1]?.toLowerCase();
                const k = /mpegurl/i.test(mime || '') || ext === 'm3u8' ? 'hls' : mime?.split(';')[0].toLowerCase() === 'application/dash+xml' || ext === 'mpd' ? 'dash' : /video\//i.test(mime || '') || ['mp4', 'm4v', 'mov', 'webm', 'ogv', 'ogg'].includes(ext || '') ? 'file' : undefined;
                if (!k)
                    return;
                const size = path.match(/\/vid\/(\d+)x(\d+)\//);
                return { url, kind: k, mime, width: finite(v.width) || finite(size?.[1]), height: finite(v.height) || finite(size?.[2]), bitrate: finite(v.bitrate ?? v.bit_rate), codecs: string(v.codecs), frameRate: finite(v.frame_rate), state: 'observed', source: 'page-data' };
            }).filter(Boolean);
            if (kind === 'image' && src)
                variants.push({ url: src, kind: 'image', width, height, state: 'observed', source: 'page-data' });
            const list = video.subtitles || info.subtitles || video.subtitle_info?.subtitles || info.subtitle_info?.subtitles || [];
            const tracks = (Array.isArray(list) ? list : []).slice(0, 64).map((t, i) => {
                const url = valid(t?.url || t?.src);
                const language = string(t?.language || t?.language_code || t?.lang);
                if (!url && !language)
                    return;
                return { id: string(t.id) || 'data-sub-' + i, kind: 'subtitles', url, language, label: string(t.label || t.name), mime: string(t.content_type), default: t.default === true, forced: t.forced === true, inBand: !url, state: 'observed', source: 'page-data' };
            }).filter(Boolean);
            const mediaId = string(m.media_key || m.id_str || m.media_id || m.rest_id || m.media_id_str || info.id);
            return { mediaId, src, kind, alt: string(m.ext_alt_text || info.alt_text) || '引用帖媒体', href, attachmentIndex: index + 1, variants, tracks,
                ...(kind !== 'image' ? { posterUrl: src, sourceUrl: variants.filter((v) => v.kind === 'file').sort((a, b) => (b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0) || ((a.codecs || '') === (b.codecs || '') ? (b.bitrate || 0) - (a.bitrate || 0) : 0))[0]?.url || variants[0]?.url, playbackUrl: typeof m.expanded_url === 'string' ? m.expanded_url : undefined } : { sourceUrl: src }) };
        });
    };
    const cardMedia = (subject, href) => {
        const values = subject?.card?.legacy?.binding_values || subject?.card?.binding_values || [];
        const entries = Array.isArray(values) ? values : Object.entries(values).map(([key, value]) => ({ key, value }));
        const byKey = {};
        for (const item of entries.slice(0, 80))
            if (item && typeof item.key === 'string' && /^(?:amplify_url_vmap|player_stream_url|player_url|video_url|player_image|thumbnail_image)$/.test(item.key))
                byKey[item.key] = item.value;
        const vars = [];
        for (const k of ['amplify_url_vmap', 'player_stream_url', 'video_url']) {
            const url = byKey[k]?.string_value;
            if (typeof url === 'string' && /^https:\/\/(?:video|pbs)\.twimg\.com\//.test(url))
                vars.push({ url, kind: k === 'amplify_url_vmap' ? 'vmap' : /\.m3u8(?:\?|$)/.test(url) ? 'hls' : /\.mpd(?:\?|$)/.test(url) ? 'dash' : 'file', source: 'page-data', state: 'observed' });
        }
        const src = byKey.player_image?.image_value?.url || byKey.thumbnail_image?.image_value?.url;
        return vars.length && typeof src === 'string' ? [{ kind: 'video', src, posterUrl: src, href, variants: vars, alt: '嵌入视频' }] : [];
    };
    const publicQuote = (item, depth = 0) => {
        if (depth > 3 || !item || typeof item !== 'object')
            return;
        const q = item.tweet || item, legacy = q.legacy || {}, id = String(q.rest_id || legacy.id_str || '');
        if (!/^\d+$/.test(id))
            return;
        const user = q.core?.user_results?.result, userLegacy = user?.legacy || {}, name = user?.core?.name || userLegacy.name, handle = user?.core?.screen_name || userLegacy.screen_name;
        const fullText = q.note_tweet?.note_tweet_results?.result?.text || legacy.full_text;
        const result = { id, url: /^[A-Za-z0-9_]+$/.test(handle || '') ? `https://x.com/${handle}/status/${id}` : `https://x.com/i/web/status/${id}` };
        if (typeof name === 'string' && typeof handle === 'string')
            result.author = { name: name.slice(0, 200), handle: handle.slice(0, 40), avatar: user?.avatar?.image_url || userLegacy.profile_image_url_https, verified: !!(user?.is_blue_verified || userLegacy.verified) };
        if (typeof fullText === 'string')
            result.fullText = fullText.slice(0, 400000);
        const date = new Date(legacy.created_at);
        if (!isNaN(+date))
            result.published = date.toISOString();
        result.media = publicMedia(q, result.url);
        const nested = publicQuote(q.quoted_status_result?.result, depth + 1);
        if (nested)
            result.quote = nested;
        return result;
    };
    const nodes = [...win.document.querySelectorAll('article[data-testid="tweet"], [data-testid="twitterArticleReadView"], [data-testid="twitterArticleRichTextView"]')];
    for (const el of nodes) {
        const key = Object.keys(el).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactProps$'));
        if (!key)
            continue;
        const queue = [[el[key], 0]], seen = new WeakSet();
        let budget = 2200;
        while (queue.length && budget-- > 0) {
            const [obj, depth] = queue.shift();
            if (!obj || typeof obj !== 'object' || seen.has(obj))
                continue;
            seen.add(obj);
            let id;
            try {
                id = String(obj.rest_id || obj.id_str || obj.legacy?.id_str || obj.id || '');
            }
            catch {
                continue;
            }
            if (id && wanted.has(id) && (obj.legacy && (obj.legacy.full_text !== undefined || obj.note_tweet) || obj.media_entities || obj.article?.media_entities || obj.article_results?.result?.media_entities || obj.attachments?.media_keys)) {
                const l = obj.legacy || {}, n = obj.note_tweet?.note_tweet_results?.result;
                const text = typeof n?.text === 'string' ? n.text : typeof l.full_text === 'string' ? l.full_text : undefined;
                const data = { id, relationEvidence: 'data', media: [...publicMedia(obj, `https://x.com/i/web/status/${id}`), ...cardMedia(obj, `https://x.com/i/web/status/${id}`)] };
                if (/^\d+$/.test(l.in_reply_to_status_id_str || ''))
                    data.parentId = l.in_reply_to_status_id_str;
                if (/^\d+$/.test(l.conversation_id_str || ''))
                    data.conversationId = l.conversation_id_str;
                if (text && text.length < 400000) {
                    // Expanded URLs and exact Unicode text are preferred over shortened t.co text.
                    const entities = n?.entity_set || l.entities || {};
                    let expanded = text;
                    for (const u of entities.urls || [])
                        if (u.url && u.expanded_url)
                            expanded = expanded.split(u.url).join(u.expanded_url);
                    data.fullText = expanded;
                }
                const q = publicQuote(obj.quoted_status_result?.result);
                if (q)
                    data.quote = q;
                if (/^\d+$/.test(l.quoted_status_id_str || ''))
                    data.quotedId = l.quoted_status_id_str;
                found.set(id, data);
            }
            if (depth >= 9)
                continue;
            let keys;
            try {
                keys = Object.keys(obj);
            }
            catch {
                continue;
            }
            for (const k of keys) {
                if (['return', 'stateNode', 'alternate', 'ownerDocument', 'parentNode', '_owner', 'ref', 'updateQueue', 'dependencies'].includes(k))
                    continue;
                if (/token|cookie|session|auth|password/i.test(k))
                    continue;
                try {
                    const val = obj[k];
                    if (val && typeof val === 'object' && !(val instanceof win.Node))
                        queue.push([val, depth + 1]);
                }
                catch { }
            }
        }
    }
    return [...found.values()];
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeBytes = nativeBytes;
exports.createHost = createHost;
const resource_network_1 = __require(1);
const model_1 = __require(7);
const urls_1 = __require(3);
const binary_1 = __require(4);
const probe_1 = __require(5);
async function nativeBytes(url, signal) {
    const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 35000);
    const abort = () => ctrl.abort();
    signal?.addEventListener('abort', abort, { once: true });
    try {
        const r = await fetch(url, { signal: ctrl.signal, credentials: 'omit', referrerPolicy: 'no-referrer', redirect: 'error' });
        if (!r.ok)
            throw new Error(`资源请求失败 (${r.status})`);
        const max = url === model_1.FONT_URL ? 28 * 1024 * 1024 : 20 * 1024 * 1024;
        if (Number(r.headers.get('content-length')) > max)
            throw new Error('资源超过安全大小限制。');
        if (!r.body) {
            const b = new Uint8Array(await r.arrayBuffer());
            if (b.length > max)
                throw new Error('资源过大。');
            return b;
        }
        const reader = r.body.getReader(), chunks = [];
        let size = 0;
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            size += value.byteLength;
            if (size > max) {
                await reader.cancel();
                throw new Error('资源超过安全大小限制。');
            }
            chunks.push(value);
        }
        const bytes = new Uint8Array(size);
        let p = 0;
        for (const c of chunks) {
            bytes.set(c, p);
            p += c.length;
        }
        return bytes;
    }
    finally {
        clearTimeout(timer);
        signal?.removeEventListener('abort', abort);
    }
}
function gmRequest(url, signal) {
    return new Promise((resolve, reject) => {
        const modern = typeof GM !== 'undefined' ? GM : undefined;
        const send = typeof GM_xmlhttpRequest === 'function' ? GM_xmlhttpRequest : modern?.xmlHttpRequest;
        if (!send) {
            reject(new Error('脚本管理器未提供 GM_xmlhttpRequest。'));
            return;
        }
        let request, ended = false;
        const finish = (error, b) => { if (ended)
            return; ended = true; signal?.removeEventListener('abort', cancel); error ? reject(error) : resolve(b); };
        const cancel = () => { try {
            request?.abort();
        }
        catch { } finish(new DOMException('已取消', 'AbortError')); };
        if (signal?.aborted) {
            cancel();
            return;
        }
        signal?.addEventListener('abort', cancel, { once: true });
        request = send({ url, method: 'GET', anonymous: true, responseType: 'arraybuffer', timeout: 35000, onload: async (r) => {
                try {
                    if (r.status < 200 || r.status >= 300)
                        throw new Error(`资源请求失败 (${r.status})`);
                    let b;
                    if (r.response instanceof ArrayBuffer)
                        b = new Uint8Array(r.response);
                    else if (ArrayBuffer.isView(r.response))
                        b = new Uint8Array(r.response.buffer, r.response.byteOffset, r.response.byteLength);
                    else if (r.response instanceof Blob)
                        b = new Uint8Array(await r.response.arrayBuffer());
                    else
                        throw new Error('Stay 返回的二进制资源格式不受支持。');
                    if (b.length > (url === model_1.FONT_URL ? 28 : 20) * 1024 * 1024)
                        throw new Error('资源超过安全大小限制。');
                    finish(undefined, b);
                }
                catch (e) {
                    finish(e);
                }
            }, onerror: () => finish(new Error('资源加载失败，请检查网络或 Stay 的站点权限。')), ontimeout: () => finish(new Error('资源加载超时。')), onabort: cancel });
    });
}
/** A stalled mobile bridge must not prevent the studio from appearing. */
function storageRead(read, fallback) {
    return new Promise(resolve => {
        let done = false;
        const finish = (v) => { if (done)
            return; done = true; clearTimeout(timer); resolve(v); };
        const timer = setTimeout(() => finish(fallback), 2000);
        try {
            Promise.resolve(read()).then(v => finish(v === undefined ? fallback : v), () => finish(fallback));
        }
        catch {
            finish(fallback);
        }
    });
}
function createHost(kind) {
    if (kind === 'extension')
        return { kind,
            async getValue(key, fallback) { const v = await chrome.storage.local.get(key); return v[key] ?? fallback; },
            async setValue(key, value) { await chrome.storage.local.set({ [key]: value }); },
            async readBytes(url, signal) {
                if (!(0, urls_1.allowedAsset)(url))
                    throw new Error('资源域名不在允许列表。');
                if (signal?.aborted)
                    throw new DOMException('已取消', 'AbortError');
                const res = await chrome.runtime.sendMessage({ type: 'xc:asset', url });
                if (!res?.ok)
                    throw new Error(res?.error || '资源读取失败。');
                if (signal?.aborted)
                    throw new DOMException('已取消', 'AbortError');
                return (0, binary_1.unbase64)(res.data);
            },
            async readResource(request, signal) {
                const id = typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : Array.from(crypto.getRandomValues(new Uint32Array(4)), v => v.toString(16)).join('-');
                const cancel = () => { void chrome.runtime.sendMessage({ type: 'xc:resource-cancel', requestId: id }).catch(() => { }); };
                if (signal?.aborted)
                    return { status: 0, url: request.url, mime: '', bytes: new Uint8Array(), problem: 'cancelled' };
                signal?.addEventListener('abort', cancel, { once: true });
                try {
                    const r = await chrome.runtime.sendMessage({ type: 'xc:resource', requestId: id, request });
                    if (signal?.aborted)
                        return { status: 0, url: request.url, mime: '', bytes: new Uint8Array(), problem: 'cancelled' };
                    if (!r?.ok)
                        return { status: 0, url: request.url, mime: '', bytes: new Uint8Array(), problem: 'network-or-cors' };
                    return { ...r.response, bytes: (0, binary_1.unbase64)(r.data || '') };
                }
                finally {
                    signal?.removeEventListener('abort', cancel);
                }
            },
            async probe(ids) { const r = await chrome.runtime.sendMessage({ type: 'xc:probe', ids }); return r?.data || []; } };
    return { kind,
        async getValue(key, fallback) { try {
            if (kind === 'stay') {
                if (typeof GM_getValue === 'function')
                    return await storageRead(() => GM_getValue(key, fallback), fallback);
                if (typeof GM !== 'undefined' && GM.getValue)
                    return await storageRead(() => GM.getValue(key, fallback), fallback);
            }
            const v = localStorage.getItem('xc:' + key);
            return v ? JSON.parse(v) : fallback;
        }
        catch {
            return fallback;
        } },
        async setValue(key, value) { if (kind === 'stay') {
            if (typeof GM_setValue === 'function') {
                await GM_setValue(key, value);
                return;
            }
            if (typeof GM !== 'undefined' && GM.setValue) {
                await GM.setValue(key, value);
                return;
            }
        } localStorage.setItem('xc:' + key, JSON.stringify(value)); },
        async readBytes(url, signal) { if (!(0, urls_1.allowedAsset)(url))
            throw new Error('资源域名不在允许列表。'); if (kind === 'stay') {
            try {
                return await gmRequest(url, signal);
            }
            catch (e) {
                if (signal?.aborted)
                    throw e;
                return nativeBytes(url, signal);
            }
        } return nativeBytes(url, signal); },
        readResource: resource_network_1.nativeResource,
        async probe(ids) { return (0, probe_1.pageProbe)(ids, window); } };
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FONT_CACHE_KEY = exports.FONT_URL = exports.VERSION = void 0;
/** Captured facts are separate from selection, style and inferred relationships. */
exports.VERSION = '1.0.0-rc.7';
exports.FONT_URL = 'https://raw.githubusercontent.com/notofonts/noto-cjk/Sans2.004/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf';
exports.FONT_CACHE_KEY = 'noto-cjk-sc-Sans2.004';

}];const cache={};function requireModule(id){if(cache[id])return cache[id].exports;const m=cache[id]={exports:{}};modules[id](m,m.exports,requireModule);return m.exports;}return requireModule(0);})();
