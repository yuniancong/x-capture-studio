(function(){'use strict';const modules=[function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const network_observer_1 = __require(1);
const observation = new network_observer_1.ChromeObservationBridge(chrome);
const resource_network_1 = __require(4);
const resourceTasks = new Map();
const resourceRate = new Map();
const urls_1 = __require(5);
const binary_1 = __require(6);
const probe_1 = __require(7);
const host_1 = __require(8);
const isX = (url) => { try {
    return /^(?:www\.|mobile\.)?(?:x\.com|twitter\.com)$/.test(new URL(url).hostname);
}
catch {
    return false;
} };
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !sender.tab?.id || !isX(sender.tab.url || sender.url || ''))
        return false;
    if (msg?.type === 'xc:observe') {
        observation.command(msg.action, sender, msg.sessionId).then(respond).catch(() => respond({ state: 'unavailable', records: [] }));
        return true;
    }
    if (msg?.type === 'xc:observe-enable') {
        observation.openPermissionPage(sender).then(ok => respond({ ok })).catch(() => respond({ ok: false }));
        return true;
    }
    if (msg?.type === 'xc:asset') {
        if (typeof msg.url !== 'string' || !(0, urls_1.allowedAsset)(msg.url)) {
            respond({ ok: false, error: '资源地址不在允许列表。' });
            return false;
        }
        (0, host_1.nativeBytes)(msg.url).then(b => respond({ ok: true, data: (0, binary_1.base64)(b) })).catch(e => respond({ ok: false, error: e.message }));
        return true;
    }
    if (msg?.type === 'xc:resource-cancel') {
        const key = sender.tab.id + ':' + msg.requestId;
        resourceTasks.get(key)?.abort();
        respond({ ok: true });
        return false;
    }
    if (msg?.type === 'xc:resource') {
        const r = (0, resource_network_1.safeResourceRequest)(msg.request);
        const id = typeof msg.requestId === 'string' && /^[\w-]{1,80}$/.test(msg.requestId) ? msg.requestId : undefined;
        if (!r || !id) {
            respond({ ok: false });
            return false;
        }
        const tab = sender.tab.id, now = Date.now(), limit = resourceRate.get(tab);
        if (limit && now - limit.at < 60000 && limit.count >= 64) {
            respond({ ok: false });
            return false;
        }
        if (resourceTasks.size >= 8) {
            respond({ ok: false });
            return false;
        }
        if (resourceRate.size > 200)
            resourceRate.clear();
        resourceRate.set(tab, limit && now - limit.at < 60000 ? { ...limit, count: limit.count + 1 } : { at: now, count: 1 });
        const key = tab + ':' + id, ctrl = new AbortController();
        resourceTasks.set(key, ctrl);
        (0, resource_network_1.nativeResource)(r, ctrl.signal).then(response => { const { bytes, ...meta } = response; respond({ ok: true, response: meta, data: (0, binary_1.base64)(bytes) }); }).catch(() => respond({ ok: false })).finally(() => resourceTasks.delete(key));
        return true;
    }
    if (msg?.type === 'xc:probe') {
        const ids = Array.isArray(msg.ids) ? msg.ids.filter((id) => typeof id === 'string' && /^\d+$/.test(id)).slice(0, 250) : [];
        chrome.scripting.executeScript({ target: { tabId: sender.tab.id }, world: 'MAIN', func: probe_1.pageProbe, args: [ids] }).then((r) => respond({ ok: true, data: r[0]?.result || [] })).catch(() => respond({ ok: false, data: [] }));
        return true;
    }
    return false;
});

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChromeObservationBridge = void 0;
const discovery_1 = __require(2);
const KEY = 'xc-media-observation-v1', ALARM = 'xc-media-observation-expiry';
const FILTER = { urls: ['https://video.twimg.com/*'], types: ['media', 'xmlhttprequest', 'other'] };
/** Adapter only: synchronous listener registration, serialized state, memory-only session storage. */
class ChromeObservationBridge {
    constructor(api, now = () => Date.now()) {
        this.api = api;
        this.now = now;
        this.ledger = new discovery_1.ObservationLedger();
        this.queue = Promise.resolve();
        this.bound = false;
        this.healthy = false;
        this.healthy = !!(api.storage?.session && api.alarms?.onAlarm);
        // Register listeners before any await: worker wakes on events even after suspension.
        this.bind();
        api.permissions?.onAdded?.addListener((p) => { if (p.permissions?.includes('webRequest'))
            this.bind(); });
        api.permissions?.onRemoved?.addListener((p) => { if (p.permissions?.includes('webRequest'))
            void this.run(async () => { this.ledger = new discovery_1.ObservationLedger(); await this.save(); }); });
        api.tabs?.onRemoved?.addListener((tabId) => { void this.run(async () => { this.ledger.stop(tabId); await this.save(); }); });
        api.tabs?.onUpdated?.addListener((tabId, change) => {
            if (change.status !== 'loading' && !change.url)
                return;
            void this.run(async () => { const s = this.ledger.session(tabId); if (s && (change.status === 'loading' || (0, discovery_1.xPageKey)(change.url) !== s.page)) {
                this.ledger.stop(tabId);
                await this.save();
            } });
        });
        api.alarms?.onAlarm?.addListener((alarm) => { if (alarm.name === ALARM)
            void this.run(() => this.save()); });
        // Events received during hydration are queued AFTER this operation.
        this.queue = (async () => {
            if (!this.healthy)
                return;
            try {
                const data = await api.storage.session.get(KEY);
                this.ledger = new discovery_1.ObservationLedger(data?.[KEY], this.now());
                await this.save();
            }
            catch {
                this.healthy = false;
                this.ledger = new discovery_1.ObservationLedger();
            }
        })();
    }
    bind() {
        if (this.bound || !this.api.webRequest)
            return;
        const api = this.api;
        const project = (d, error = false) => ({ tabId: d.tabId, frameId: d.frameId, documentId: d.documentId, initiator: d.initiator,
            url: d.url, type: d.type, requestId: d.requestId, statusCode: d.statusCode, error,
            // Immediately discard other header values; never store an event object.
            mime: typeof d.responseHeaders?.find((h) => h.name?.toLowerCase() === 'content-type')?.value === 'string' ?
                d.responseHeaders.find((h) => h.name?.toLowerCase() === 'content-type').value.split(';')[0].slice(0, 120) : undefined });
        const before = (d) => this.event(project(d));
        const response = (d) => this.event(project(d));
        const error = (d) => this.event(project(d, true));
        try {
            api.webRequest.onBeforeRequest.addListener(before, FILTER);
            api.webRequest.onResponseStarted.addListener(response, FILTER, ['responseHeaders']);
            api.webRequest.onErrorOccurred.addListener(error, FILTER);
            this.bound = true;
        }
        catch {
            // Partial registration never counts as availability.
            api.webRequest.onBeforeRequest?.removeListener?.(before);
            api.webRequest.onResponseStarted?.removeListener?.(response);
            api.webRequest.onErrorOccurred?.removeListener?.(error);
        }
    }
    run(fn) {
        const next = this.queue.then(fn, fn);
        this.queue = next.catch(() => { });
        return next;
    }
    event(event) {
        const at = this.now();
        void this.run(async () => {
            if (!this.healthy || !this.bound)
                return;
            if (this.ledger.record(event, at))
                await this.save();
        }).catch(() => { });
    }
    async save() {
        const sessions = this.ledger.dump(this.now());
        if (this.healthy) {
            try {
                if (sessions.length)
                    await this.api.storage.session.set({ [KEY]: sessions });
                else
                    await this.api.storage.session.remove(KEY);
            }
            catch {
                this.healthy = false;
                this.ledger = new discovery_1.ObservationLedger();
                try {
                    await this.api.storage.session.remove(KEY);
                }
                catch { }
            }
        }
        const next = this.healthy && sessions.length ? Math.min(...sessions.map(s => s.expiresAt)) : undefined;
        if (next === this.expiry)
            return;
        this.expiry = next;
        if (this.timer)
            clearTimeout(this.timer);
        if (next) {
            try {
                await this.api.alarms.create(ALARM, { when: next });
            }
            catch {
                this.healthy = false;
                this.ledger = new discovery_1.ObservationLedger();
                await this.api.storage.session.remove(KEY).catch(() => { });
            }
            this.timer = setTimeout(() => void this.run(() => this.save()), Math.max(1, next - this.now()));
            this.timer.unref?.();
        }
        else
            try {
                await this.api.alarms?.clear(ALARM);
            }
            catch { }
    }
    context(sender, sessionId) {
        if (sender?.id !== this.api.runtime.id || sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !sender.documentId)
            return;
        const page = (0, discovery_1.xPageKey)(sender.url), tabPage = (0, discovery_1.xPageKey)(sender.tab.url);
        if (!page || page !== tabPage || typeof sessionId !== 'string' || !/^[A-Za-z0-9_-]{8,100}$/.test(sessionId))
            return;
        return { tabId: sender.tab.id, documentId: sender.documentId, page, sessionId };
    }
    async command(action, sender, sessionId) {
        const c = this.context(sender, sessionId);
        if (!c)
            return { state: 'scope-changed', records: [] };
        return this.run(async () => {
            if (action === 'stop') {
                this.ledger.stop(c.tabId, c.sessionId);
                await this.save();
                return { state: 'stopped', records: [] };
            }
            if (!this.healthy)
                return { state: 'unsupported', records: [] };
            const granted = await this.api.permissions.contains({ permissions: ['webRequest'] }).catch(() => false);
            if (!granted)
                return { state: 'permission-required', records: [] };
            if (!this.bound)
                return { state: 'unsupported', records: [] };
            if (action === 'start' && !this.ledger.begin(c, this.now()))
                return { state: 'unavailable', records: [] };
            if (!['start', 'poll'].includes(action))
                return { state: 'unsupported', records: [] };
            const result = this.ledger.poll(c, this.now());
            await this.save();
            return result;
        });
    }
    /** Called only by the extension's visible button; no consent is inferred from page content. */
    async openPermissionPage(sender) {
        if (!this.context(sender, 'permission-page'))
            return false;
        await this.api.tabs.create({ url: this.api.runtime.getURL('observation.html') + '?returnTab=' + sender.tab.id });
        return true;
    }
    /** Test/diagnostic barrier: no raw URLs are logged. */
    settled() { return this.queue; }
}
exports.ChromeObservationBridge = ChromeObservationBridge;

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObservationLedger = exports.OBSERVATION_LIMITS = void 0;
exports.xPageKey = xPageKey;
exports.observedMediaURL = observedMediaURL;
exports.acceptedVariant = acceptedVariant;
exports.mediaFamilies = mediaFamilies;
exports.attachObservations = attachObservations;
exports.performanceMediaEntries = performanceMediaEntries;
exports.resourceDiagnostics = resourceDiagnostics;
const resources_1 = __require(3);
exports.OBSERVATION_LIMITS = { durationMs: 30000, maxSessions: 8, maxRecords: 96, maxURLLength: 4096 };
function xPageKey(value) {
    if (typeof value !== 'string')
        return;
    try {
        const u = new URL(value);
        if (u.protocol !== 'https:' || u.username || u.password || u.port || !/^(?:www\.|mobile\.)?(?:x\.com|twitter\.com)$/.test(u.hostname))
            return;
        return u.origin + u.pathname;
    }
    catch {
        return;
    }
}
/** A small approved media endpoint set, not a browser-history collector. */
function observedMediaURL(value) {
    if (typeof value !== 'string' || value.length > exports.OBSERVATION_LIMITS.maxURLLength)
        return;
    const url = (0, resources_1.resourceURL)(value);
    if (!url)
        return;
    const u = new URL(url);
    if (u.protocol !== 'https:' || u.port || u.hostname !== 'video.twimg.com')
        return;
    return url;
}
function contextOK(v) {
    return Number.isInteger(v.tabId) && v.tabId >= 0 && !!xPageKey(v.page) &&
        typeof v.documentId === 'string' && v.documentId.length > 0 && v.documentId.length <= 160 &&
        /^[A-Za-z0-9_-]{8,100}$/.test(v.sessionId);
}
function acceptedVariant(url, mime = '') {
    const v = (0, resources_1.variant)({ url, mime }, 'network');
    return v && ['file', 'hls', 'dash', 'audio', 'subtitle', 'vmap', 'segment'].includes(v.kind) ? v : undefined;
}
/** Pure, bounded session policy. Chrome integration below it never persists arbitrary event objects. */
class ObservationLedger {
    constructor(saved = [], now = Date.now()) {
        this.sessions = new Map();
        if (!Array.isArray(saved))
            return;
        for (const raw of saved.slice(0, exports.OBSERVATION_LIMITS.maxSessions)) {
            if (!raw || !contextOK(raw) || !Number.isFinite(raw.startedAt) || !Number.isFinite(raw.expiresAt) || raw.expiresAt <= now ||
                raw.expiresAt - raw.startedAt > exports.OBSERVATION_LIMITS.durationMs || raw.startedAt > now)
                continue;
            const session = { tabId: raw.tabId, documentId: raw.documentId, page: xPageKey(raw.page), sessionId: raw.sessionId,
                startedAt: raw.startedAt, expiresAt: raw.expiresAt, records: [], limited: raw.limited === true, segments: Math.min(9999, Math.max(0, Number(raw.segments) || 0)) };
            for (const r of (Array.isArray(raw.records) ? raw.records : []).slice(0, exports.OBSERVATION_LIMITS.maxRecords)) {
                const url = observedMediaURL(r?.url);
                if (!url || !acceptedVariant(url, r.mime) || !Number.isFinite(r.observedAt) || r.observedAt < session.startedAt || r.observedAt > now)
                    continue;
                session.records.push({ url, mime: typeof r.mime === 'string' ? r.mime.slice(0, 120) : undefined, status: Number.isInteger(r.status) ? r.status : undefined,
                    frameId: 0, source: 'network', observedAt: r.observedAt, requestType: ['media', 'xmlhttprequest', 'other'].includes(r.requestType) ? r.requestType : undefined,
                    problem: r.problem === 'request-error' ? 'request-error' : undefined });
            }
            this.sessions.set(raw.tabId, session);
        }
    }
    prune(now = Date.now()) { for (const [id, s] of this.sessions)
        if (s.expiresAt <= now)
            this.sessions.delete(id); }
    begin(c, now = Date.now()) {
        this.prune(now);
        if (!contextOK(c) || this.sessions.size >= exports.OBSERVATION_LIMITS.maxSessions && !this.sessions.has(c.tabId))
            return false;
        this.sessions.set(c.tabId, { ...c, page: xPageKey(c.page), startedAt: now, expiresAt: now + exports.OBSERVATION_LIMITS.durationMs, records: [], limited: false, segments: 0 });
        return true;
    }
    allows(e, now = Date.now()) {
        this.prune(now);
        const s = this.sessions.get(e.tabId);
        // Only top-document X requests. Foreign and opaque initiators fail closed.
        if (!s || now < s.startedAt || e.frameId !== 0 || !xPageKey(e.initiator) || new URL(e.initiator).origin !== new URL(s.page).origin ||
            e.documentId && e.documentId !== s.documentId || !['media', 'xmlhttprequest', 'other'].includes(e.type) || !observedMediaURL(e.url))
            return false;
        return true;
    }
    record(e, now = Date.now()) {
        if (!this.allows(e, now))
            return false;
        const s = this.sessions.get(e.tabId);
        const url = observedMediaURL(e.url), v = acceptedVariant(url, e.mime);
        if (!v)
            return false;
        if (v.kind === 'segment') {
            s.segments = Math.min(9999, s.segments + 1);
            return false;
        }
        const old = s.records.find(r => r.url === url);
        if (!old && s.records.length >= exports.OBSERVATION_LIMITS.maxRecords) {
            s.limited = true;
            return false;
        }
        const r = { url, source: 'network', frameId: e.frameId, observedAt: old?.observedAt ?? now,
            mime: e.mime?.split(';')[0].trim().toLowerCase().slice(0, 120) || old?.mime, status: e.statusCode ?? old?.status,
            requestType: e.type, problem: e.error ? 'request-error' : old?.problem };
        if (old)
            s.records[s.records.indexOf(old)] = r;
        else
            s.records.push(r);
        return true;
    }
    poll(c, now = Date.now()) {
        const s = this.sessions.get(c.tabId);
        if (!s)
            return { state: 'stopped', records: [] };
        if (s.sessionId !== c.sessionId || s.documentId !== c.documentId || s.page !== xPageKey(c.page))
            return { state: 'scope-changed', records: [] };
        if (s.expiresAt <= now) {
            this.sessions.delete(c.tabId);
            return { state: 'expired', records: [] };
        }
        return { state: 'active', records: s.records.map(r => ({ ...r })), expiresAt: s.expiresAt, limited: s.limited, segments: s.segments };
    }
    stop(tabId, sessionId) { const s = this.sessions.get(tabId); if (s && (!sessionId || sessionId === s.sessionId))
        this.sessions.delete(tabId); }
    session(tabId) { return this.sessions.get(tabId); }
    dump(now = Date.now()) { this.prune(now); return [...this.sessions.values()].map(s => ({ ...s, records: s.records.map(r => ({ ...r })) })); }
}
exports.ObservationLedger = ObservationLedger;
/** CDN resource identifiers are media IDs, NOT tweet IDs; thumbnails supply identity evidence too. */
function mediaFamilies(value) {
    const url = (0, resources_1.resourceURL)(value);
    if (!url)
        return [];
    const u = new URL(url);
    if (!['video.twimg.com', 'pbs.twimg.com'].includes(u.hostname))
        return [];
    const m = u.pathname.match(/^\/(amplify_video|ext_tw_video)(?:_thumb)?\/(\d+)(?:\/|$)/);
    if (m)
        return [m[1] + ':' + m[2], 'media-id:' + m[2]];
    const gif = u.pathname.match(/^\/tweet_video(?:_thumb)?\/([A-Za-z0-9_-]+)(?:\.[a-z0-9]+)?$/i);
    return gif ? ['tweet-video:' + gif[1]] : [];
}
function mediaIdentity(m) {
    const keys = new Set();
    for (const u of [m.posterUrl, m.src, m.sourceUrl, ...(0, resources_1.existingVariants)(m).map(v => v.url)])
        if (u)
            for (const k of mediaFamilies(u))
                keys.add(k);
    const id = m.mediaId?.match(/^(?:\d+_)?(\d+)$/)?.[1];
    if (id)
        keys.add('media-id:' + id);
    return keys;
}
/** Attach only with exact URL or a unique confirmed media-family identity. Never use time proximity alone. */
function attachObservations(c, selected, records, quotes = true) {
    const targets = [];
    (0, resources_1.visitMedia)(c, selected, m => { if (m.kind !== 'image')
        targets.push(m); }, quotes);
    const identities = targets.map(mediaIdentity), urls = targets.map(m => new Set((0, resources_1.existingVariants)(m).map(v => v.url)));
    const result = { matched: 0, unmatched: 0, ambiguous: 0, segments: 0, ignored: 0, formats: [], pending: [] };
    const seen = new Set();
    for (const r of records.slice(0, 192)) {
        const url = observedMediaURL(r.url);
        if (!url || seen.has(url)) {
            result.ignored++;
            continue;
        }
        seen.add(url);
        const v = (0, resources_1.variant)({ url, mime: r.mime }, r.source === 'performance' ? 'performance' : 'network');
        if (!v || !['file', 'hls', 'dash', 'vmap', 'audio', 'subtitle', 'segment'].includes(v.kind)) {
            result.ignored++;
            continue;
        }
        if (v.kind === 'segment') {
            result.segments++;
            continue;
        }
        const exact = targets.map((_, i) => urls[i].has(url) ? i : -1).filter(i => i >= 0);
        const family = mediaFamilies(url);
        const matches = exact.length ? exact : identities.map((id, i) => family.some(k => id.has(k)) ? i : -1).filter(i => i >= 0);
        if (matches.length !== 1) {
            matches.length ? result.ambiguous++ : result.unmatched++;
            result.pending.push({ ...r, url });
            continue;
        }
        const m = targets[matches[0]];
        v.discoveredAt = new Date(r.observedAt).toISOString();
        v.httpStatus = r.status;
        // Successful request observation is not file/manifest validation.
        if (r.status === 404 || r.status === 410) {
            v.state = 'unavailable';
            v.problem = 'not-found';
        }
        else if (r.status && r.status >= 400 || r.problem) {
            v.state = 'unverified';
            v.problem = r.status === 401 || r.status === 403 ? 'forbidden' : 'network-or-cors';
        }
        m.variants = (0, resources_1.mergeVariants)(m.variants, [v]);
        if (v.kind === 'subtitle')
            m.tracks = (0, resources_1.mergeTracks)(m.tracks, [{ id: 'observed-sub:' + url, kind: 'subtitles', url, format: (0, resources_1.mediaFormat)(url, r.mime), mime: r.mime,
                    state: 'observed', source: v.source, evidence: 'url-observed' }]);
        result.matched++;
        if (!result.formats.includes(v.kind))
            result.formats.push(v.kind);
    }
    return result;
}
/** Read only allowlisted names already in this document's performance timeline. TAO is not bypassed. */
function performanceMediaEntries(p, now = Date.now()) {
    try {
        const out = [], seen = new Set();
        for (const e of p.getEntriesByType('resource').slice(-512).reverse()) {
            const url = observedMediaURL(e.name);
            if (!url || seen.has(url))
                continue;
            const observedAt = p.timeOrigin + e.startTime;
            if (!Number.isFinite(observedAt) || observedAt > now + 1000 || now - observedAt > 120000)
                continue;
            const v = acceptedVariant(url);
            if (!v || v.kind === 'segment')
                continue;
            seen.add(url);
            out.push({ url, source: 'performance', frameId: 0, observedAt });
            if (out.length >= 96)
                break;
        }
        return out;
    }
    catch {
        return [];
    }
}
/** Diagnostics intentionally contain no URLs, account handles, titles, or signed query parameters. */
function resourceDiagnostics(c, selected, quotes = true) {
    const lines = [];
    let n = 0;
    (0, resources_1.visitMedia)(c, selected, m => {
        if (m.kind === 'image')
            return;
        n++;
        const vs = (0, resources_1.existingVariants)(m), from = (s) => vs.filter(v => (v.sources || [v.source]).includes(s)).length;
        const kinds = ['file', 'hls', 'dash'].map(k => k.toUpperCase() + ':' + vs.filter(v => v.kind === k && !v.segmented).length).join(' ');
        const tracks = m.tracks || [], hints = tracks.filter(t => t.evidence === 'hint' || !t.evidence && t.source === 'track' && !t.url).length;
        lines.push(`视频 ${n}｜DOM ${m.domSourceKind || '未记录'}｜页面数据 ${from('page-data')}｜网络 ${from('network')}｜时间线条目 ${from('performance')}｜${kinds}｜已解析清单 ${(m.manifests || []).length}｜字幕元信息 ${hints} / 轨道 ${tracks.length}`);
    }, quotes);
    return lines.length ? lines : ['已选内容中没有视频。'];
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resourceURL = resourceURL;
exports.sensitiveURL = sensitiveURL;
exports.fetchableResource = fetchableResource;
exports.mediaFormat = mediaFormat;
exports.classifyResource = classifyResource;
exports.variant = variant;
exports.variantKey = variantKey;
exports.mergeVariants = mergeVariants;
exports.trackEvidence = trackEvidence;
exports.mergeTracks = mergeTracks;
exports.sameMediaKey = sameMediaKey;
exports.existingVariants = existingVariants;
exports.mergeMediaResources = mergeMediaResources;
exports.imageCandidates = imageCandidates;
exports.preferredImage = preferredImage;
exports.recommendedVariants = recommendedVariants;
exports.visitMedia = visitMedia;
function resourceURL(value, base) {
    if (typeof value !== 'string' || value.length > 12000 || /[\u0000-\u0020\u007f\\]/.test(value))
        return;
    try {
        const u = new URL(value, base);
        if (!['https:', 'http:'].includes(u.protocol) || u.username || u.password)
            return;
        if (!u.hostname || /^(?:localhost|.*\.localhost|.*\.local|.*\.internal|.*\.lan)$/.test(u.hostname) || u.hostname.includes(':') || /^\d+(?:\.\d+){0,3}$/.test(u.hostname))
            return;
        return u.href;
    }
    catch {
        return;
    }
}
function sensitiveURL(value) {
    try {
        const u = new URL(value);
        const keys = [...u.searchParams.keys()];
        return keys.some(k => /(?:token|signature|credential|authorization|password|secret|^sig$|^key$|api.?key|^policy$|^expires?$|^x-amz-|^x-goog-|key-pair-id|^jwt$|^auth$|^hdnea$|^hdnts$)/i.test(k)) ||
            /(?:^|[?&#])(?:access_token|token|sig|key)=/i.test(u.hash) || /\/(?:token|signature|auth)\/[^/]+/i.test(u.pathname);
    }
    catch {
        return false;
    }
}
/** Network verification is deliberately narrower than link discovery. No new host permissions. */
function fetchableResource(value) {
    const s = resourceURL(value);
    if (!s)
        return false;
    const u = new URL(s);
    return u.protocol === 'https:' && !u.port && ['pbs.twimg.com', 'video.twimg.com', 'abs.twimg.com'].includes(u.hostname);
}
function mediaFormat(url, mime = '') {
    const type = mime.split(';')[0].trim().toLowerCase();
    if (/(?:vnd\.apple\.mpegurl|x-mpegurl)/.test(type))
        return 'hls';
    if (type === 'application/dash+xml')
        return 'dash';
    if (type === 'application/ttml+xml')
        return 'ttml';
    if (type === 'text/vtt')
        return 'vtt';
    if (/subrip/.test(type))
        return 'srt';
    if (type === 'video/mp2t')
        return 'ts';
    if (/vmap|vast/.test(type))
        return 'vmap';
    const m = { 'video/mp4': 'mp4', 'video/x-m4v': 'm4v', 'video/quicktime': 'mov', 'video/webm': 'webm', 'video/ogg': 'ogv', 'audio/mp4': 'm4a', 'audio/mpeg': 'mp3', 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif' };
    if (m[type])
        return m[type];
    try {
        const u = new URL(url), ext = u.pathname.match(/\.([a-z0-9]+)(?::(?:small|large|orig|thumb|medium|\d+x\d+))?$/i)?.[1]?.toLowerCase();
        const fmt = u.hostname === 'pbs.twimg.com' ? u.searchParams.get('format') : undefined;
        return (fmt || ext || '').replace(/^m3u8$/, 'hls').replace(/^mpd$/, 'dash').replace(/^jpeg$/, 'jpg');
    }
    catch {
        return '';
    }
}
function classifyResource(url, mime = '', hint) {
    if (hint === 'segment' || hint === 'poster' || hint === 'page')
        return hint;
    const f = mediaFormat(url, mime), type = mime.toLowerCase();
    // Provenance beats extension: an MP4 may be an initialization or media segment.
    if (['ts', 'm4s', 'cmfv', 'cmfa'].includes(f) || (/\/(?:segments?|chunks?|seg)\/|\/(?:init|initialization|segment[-_]\d+)(?:\.|\/)/i.test(new URL(url).pathname) && ['mp4', 'm4v'].includes(f)))
        return 'segment';
    // X HLS fMP4: /vid|aud/<codec>/<startMs>/<endMs>/... is an init/range part, not a playable file.
    try {
        const u = new URL(url);
        if (u.hostname === 'video.twimg.com' && /\/(?:vid|aud)\/[\w.-]+\/\d+\/\d+\//.test(u.pathname) && ['mp4', 'm4a', 'm4v'].includes(f))
            return 'segment';
    }
    catch { }
    if (f === 'hls')
        return 'hls';
    if (f === 'dash')
        return 'dash';
    if (f === 'vmap')
        return 'vmap';
    if (['vtt', 'srt', 'ttml', 'dfxp'].includes(f))
        return 'subtitle';
    if (['jpg', 'png', 'gif', 'webp', 'avif'].includes(f) || type.startsWith('image/'))
        return 'image';
    if (type.startsWith('audio/') || ['aac', 'm4a', 'mp3', 'opus'].includes(f))
        return 'audio';
    if (['mp4', 'm4v', 'mov', 'webm', 'ogv', 'ogg'].includes(f) || type.startsWith('video/'))
        return 'file';
    return hint || 'unknown';
}
const positive = (v) => typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : undefined;
const word = (s, max = 180) => typeof s === 'string' ? s.replace(/[\u0000-\u001f\u007f]/g, '').slice(0, max) : undefined;
/** Whitelist fields from a page or manifest. Never copy arbitrary objects into exportable data. */
function variant(value, source = 'dom', hint, base) {
    const v = typeof value === 'string' ? { url: value } : value;
    if (!v || typeof v !== 'object')
        return;
    const url = resourceURL(v.url, base);
    if (!url)
        return;
    const mime = word(v.mime || v.content_type, 100), kind = classifyResource(url, mime, hint || v.kind);
    if (!['image', 'file', 'hls', 'dash', 'audio', 'subtitle', 'poster', 'segment', 'vmap', 'page', 'unknown'].includes(kind))
        return;
    const out = { url, kind, format: mediaFormat(url, mime) || word(v.format, 32), source, mime, state: 'observed', sensitive: sensitiveURL(url) || v.sensitive === true };
    out.sources = [...new Set([...(Array.isArray(v.sources) ? v.sources : []), source])].filter((x) => ['dom', 'srcset', 'page-data', 'image-rule', 'hls', 'dash', 'vmap', 'legacy', 'track', 'network', 'performance'].includes(x));
    for (const k of ['width', 'height', 'bitrate', 'averageBitrate', 'frameRate', 'descriptorWidth', 'descriptorDensity']) {
        const n = positive(v[k] ?? (k === 'bitrate' ? v.bit_rate : undefined));
        if (n !== undefined && n < 1e12)
            out[k] = n;
    }
    for (const k of ['codecs', 'language', 'name', 'parentUrl', 'audioGroup', 'subtitleGroup', 'captionGroup', 'periodId', 'adaptationId', 'representationId', 'discoveredAt', 'checkedAt']) {
        const t = word(v[k], k === 'parentUrl' ? 12000 : 180);
        if (t)
            out[k] = t;
    }
    if (['observed', 'candidate', 'verified', 'unverified', 'unavailable', 'blocked'].includes(v.state))
        out.state = v.state;
    if (['video', 'audio', 'subtitle', 'iframe'].includes(v.role))
        out.role = v.role;
    if (['master', 'media'].includes(v.playlist))
        out.playlist = v.playlist;
    if (['page-data', 'manifest', 'file-metadata'].includes(v.dimensionSource))
        out.dimensionSource = v.dimensionSource;
    if (v.segmented !== undefined)
        out.segmented = !!v.segmented;
    for (const k of ['encrypted', 'drm', 'live'])
        if (typeof v[k] === 'boolean')
            out[k] = v[k];
    if (v.verifiedBy && ['image-decode', 'manifest-parse', 'headers'].includes(v.verifiedBy))
        out.verifiedBy = v.verifiedBy;
    if (typeof v.httpStatus === 'number')
        out.httpStatus = v.httpStatus;
    if (typeof v.problem === 'string')
        out.problem = v.problem;
    if (out.kind === 'hls' && out.playlist === 'master') {
        delete out.width;
        delete out.height;
        delete out.dimensionSource;
    }
    return out;
}
function variantKey(v) { return [v.kind, v.url, v.role || (['hls', 'dash', 'vmap'].includes(v.kind) ? 'video' : ''), v.periodId || '', v.representationId || '', v.audioGroup || '', v.subtitleGroup || ''].join('\u001f'); }
function mergeVariants(...arrays) {
    const map = new Map();
    for (const arr of arrays)
        for (const raw of (arr || []).slice(0, 512)) {
            const v = variant(raw, raw.source, raw.kind);
            if (!v)
                continue;
            const key = variantKey(v), a = map.get(key);
            if (!a) {
                if (map.size < 512)
                    map.set(key, v);
                continue;
            }
            const out = { ...a };
            for (const [k, val] of Object.entries(v))
                if (val !== undefined)
                    out[k] = val;
            // A fresh scan cannot erase a network check. A later explicit check CAN supersede it.
            if (!v.checkedAt && a.checkedAt) {
                out.state = a.state;
                out.checkedAt = a.checkedAt;
                out.problem = a.problem;
                out.verifiedBy = a.verifiedBy;
                out.width = a.width || v.width;
                out.height = a.height || v.height;
            }
            else if (a.state === 'observed' && v.state === 'candidate')
                out.state = 'observed';
            if (a.sensitive || v.sensitive)
                out.sensitive = true;
            out.sources = [...new Set([...(a.sources || [a.source]), ...(v.sources || [v.source])])];
            if (out.kind === 'hls' && out.playlist === 'master') {
                delete out.width;
                delete out.height;
                delete out.dimensionSource;
            }
            map.set(key, out);
        }
    return [...map.values()];
}
const trackEvidenceRank = { hint: 0, declared: 1, 'url-observed': 2, 'resource-validated': 3, 'cue-confirmed': 4 };
function trackEvidence(t) {
    if (t.cueCount && t.cueCount > 0)
        return 'cue-confirmed';
    if (t.evidence && t.evidence in trackEvidenceRank)
        return t.evidence;
    if (t.url)
        return t.state === 'verified' ? 'resource-validated' : 'url-observed';
    if (['hls', 'dash', 'page-data'].includes(t.source))
        return 'declared';
    return 'hint';
}
function sameTrack(a, b) {
    if (a.kind !== b.kind)
        return false;
    for (const k of ['groupId', 'periodId', 'representationId', 'language'])
        if (a[k] && b[k] && a[k] !== b[k])
            return false;
    if (a.url && b.url)
        return a.url === b.url;
    if (a.manifestUrl && b.manifestUrl && a.manifestUrl !== b.manifestUrl)
        return false;
    if (a.inBandEvidence && b.inBandEvidence && a.id !== b.id)
        return false; // e.g. CC1 vs CC2.
    if (a.id === b.id && a.source === b.source)
        return true;
    // A browser hint may attach to ONE clearly matching named/language-declared track.
    return !!(a.language && b.language && a.language === b.language && a.label && a.label === b.label) &&
        (trackEvidence(a) === 'hint' || trackEvidence(b) === 'hint' || a.source === 'track' || b.source === 'track');
}
function mergeTracks(...arrays) {
    const out = [];
    for (const arr of arrays)
        for (const t of (arr || []).slice(0, 128)) {
            if (!t || !['audio', 'subtitles', 'captions', 'descriptions'].includes(t.kind))
                continue;
            const url = t.url ? resourceURL(t.url) : undefined, manifestUrl = t.manifestUrl ? resourceURL(t.manifestUrl) : undefined;
            const clean = { id: word(t.id, 256) || 'unknown', kind: t.kind, url, manifestUrl,
                state: t.state || 'observed', source: t.source || 'track', evidence: trackEvidence(t) };
            for (const k of ['language', 'label', 'format', 'mime', 'codecs', 'groupId', 'periodId', 'adaptationId', 'representationId'])
                clean[k] = word(t[k]);
            for (const k of ['default', 'forced', 'autoSelect', 'encrypted', 'segmented'])
                if (typeof t[k] === 'boolean')
                    clean[k] = t[k];
            // Only a real manifest declaration proves an in-band relationship.
            if (t.inBand === true && ['hls', 'dash'].includes(t.source)) {
                clean.inBand = true;
                clean.inBandEvidence = 'manifest';
            }
            else if (t.inBandEvidence === 'manifest' && t.inBand) {
                clean.inBand = true;
                clean.inBandEvidence = 'manifest';
            }
            if (t.cueCount && Number.isFinite(t.cueCount))
                clean.cueCount = Math.min(100000, Math.max(1, Math.floor(t.cueCount)));
            clean.sensitive = t.sensitive || !!url && sensitiveURL(url) || !!manifestUrl && sensitiveURL(manifestUrl);
            const candidates = out.map((v, i) => sameTrack(v, clean) ? i : -1).filter(i => i >= 0);
            if (candidates.length === 1) {
                const i = candidates[0], a = out[i];
                const merged = { ...a };
                for (const [key, value] of Object.entries(clean))
                    if (value !== undefined)
                        merged[key] = value;
                merged.evidence = trackEvidenceRank[trackEvidence(a)] > trackEvidenceRank[trackEvidence(clean)] ? trackEvidence(a) : trackEvidence(clean);
                if (a.state === 'verified' && clean.state === 'observed')
                    merged.state = a.state;
                if (a.sensitive || clean.sensitive)
                    merged.sensitive = true;
                if (a.inBandEvidence === 'manifest') {
                    merged.inBand = true;
                    merged.inBandEvidence = 'manifest';
                }
                out[i] = merged;
            }
            else if (out.length < 128)
                out.push(clean);
        }
    return out;
}
function sameMediaKey(m) {
    if (m.mediaId)
        return 'id:' + m.mediaId;
    const u = resourceURL(m.posterUrl) || resourceURL(m.src);
    if (!u)
        return;
    const a = new URL(u);
    // Only documented X image renditions share identity across format/size requests.
    if (a.hostname === 'pbs.twimg.com' && /^\/media\/[A-Za-z0-9_-]+/.test(a.pathname))
        return a.hostname + a.pathname.replace(/:(?:thumb|small|medium|large|orig|\d+x\d+)$/i, '').replace(/\.(?:jpe?g|png|webp|gif)$/i, '');
    return u;
}
function existingVariants(m) {
    const a = [];
    for (const url of m.kind === 'image' ? [m.src, m.sourceUrl] : [m.sourceUrl, m.href]) {
        const v = variant(url, 'legacy', m.kind === 'image' ? 'image' : undefined);
        if (v && ((m.kind === 'image' && v.kind === 'image') || (m.kind !== 'image' && ['file', 'hls', 'dash', 'vmap', 'audio'].includes(v.kind))))
            a.push(v);
    }
    return mergeVariants(a, m.variants);
}
function mergeMediaResources(target, incoming) {
    if (target.ownerId && incoming.ownerId && target.ownerId !== incoming.ownerId)
        return;
    if (target.mediaId && incoming.mediaId && target.mediaId !== incoming.mediaId)
        return;
    const a = existingVariants(target), b = existingVariants({ ...target, variants: [], sourceUrl: undefined, ...incoming });
    target.variants = mergeVariants(a, b);
    target.tracks = mergeTracks(target.tracks, incoming.tracks);
    target.mediaId = target.mediaId || incoming.mediaId;
    target.ownerId = target.ownerId || incoming.ownerId;
    const info = new Map((target.manifests || []).map(x => [x.url, x]));
    for (const m of incoming.manifests || [])
        info.set(m.url, m);
    target.manifests = [...info.values()].slice(0, 64);
    target.resourceNotes = [...new Set([...(target.resourceNotes || []), ...(incoming.resourceNotes || [])])].slice(0, 40);
    if (!target.selectedImageUrl && incoming.selectedImageUrl)
        target.selectedImageUrl = incoming.selectedImageUrl;
    if (incoming.playbackDimensions && (!target.playbackDimensions || incoming.playbackDimensions.observedAt >= target.playbackDimensions.observedAt))
        target.playbackDimensions = { ...incoming.playbackDimensions };
    if (incoming.domSourceKind)
        target.domSourceKind = incoming.domSourceKind;
}
/** Candidate rank is a request strategy, never an assertion about existing originals. */
function imageCandidates(m) {
    const observed = existingVariants(m).filter(v => v.kind === 'image').sort((a, b) => Number(b.source === 'page-data') - Number(a.source === 'page-data'));
    const generated = [];
    for (const v of observed) {
        const u = new URL(v.url);
        if (u.hostname !== 'pbs.twimg.com' || sensitiveURL(v.url) || u.port)
            continue;
        const match = u.pathname.match(/^\/media\/([A-Za-z0-9_-]+)(?:\.(jpe?g|png|webp|gif))?(?::(?:thumb|small|medium|large|orig|\d+x\d+))?$/i);
        if (!match)
            continue;
        const fmt = (u.searchParams.get('format') || match[2] || '').toLowerCase();
        if (!['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(fmt))
            continue;
        for (const size of fmt === 'webp' ? ['4096x4096', 'large', 'medium'] : ['orig', '4096x4096', 'large', 'medium']) {
            const c = new URL(v.url);
            c.protocol = 'https:';
            c.pathname = '/media/' + match[1];
            c.searchParams.set('format', fmt === 'jpeg' ? 'jpg' : fmt);
            c.searchParams.set('name', size);
            c.hash = '';
            const x = variant(c.href, 'image-rule', 'image');
            x.state = 'candidate';
            x.name = size;
            generated.push(x);
        }
    }
    const merged = mergeVariants(generated, observed);
    const rank = (v) => { const name = new URL(v.url).searchParams.get('name') || v.name; return name === 'orig' ? 1e9 : name === '4096x4096' ? 4096 : name === 'large' ? 2048 : name === 'medium' ? 1200 : (v.width || v.descriptorWidth || (v.descriptorDensity || 0) * 1000); };
    return merged.sort((a, b) => rank(b) - rank(a)).slice(0, 24);
}
function preferredImage(m) {
    const variants = existingVariants(m).filter(v => v.kind === 'image');
    const selected = variants.find(v => v.url === m.selectedImageUrl && !['unavailable', 'blocked'].includes(v.state) && (v.source !== 'image-rule' || v.state === 'verified'));
    if (selected)
        return selected;
    const known = variants.filter(v => v.state === 'verified' && v.verifiedBy === 'image-decode');
    if (known.length)
        return known.sort((a, b) => (b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0))[0];
    // Do not discard an observed URL solely because the checking environment has CORS/network limits.
    const ok = variants.filter(v => v.source !== 'image-rule' && v.state !== 'candidate' && v.state !== 'unavailable');
    return ok.sort((a, b) => (b.width || b.descriptorWidth || 0) - (a.width || a.descriptorWidth || 0) || ((b.descriptorDensity || 0) - (a.descriptorDensity || 0)) || Number(b.source === 'page-data') - Number(a.source === 'page-data'))[0] || variants.find(v => v.source !== 'image-rule');
}
function recommendedVariants(m, all = false) {
    const a = existingVariants(m).filter(v => !['candidate', 'unavailable'].includes(v.state) && ['file', 'hls', 'dash', 'audio', 'vmap'].includes(v.kind) && v.role !== 'iframe' && v.role !== 'subtitle' && v.role !== 'audio');
    if (all)
        return a;
    const out = [];
    for (const kind of ['file', 'hls', 'dash', 'vmap']) {
        const group = a.filter(v => v.kind === kind);
        group.sort((a, b) => Number(b.playlist === 'master' || (!b.parentUrl && !b.representationId)) - Number(a.playlist === 'master' || (!a.parentUrl && !a.representationId)) ||
            ((b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0)) || ((a.codecs || '') === (b.codecs || '') ? (b.bitrate || 0) - (a.bitrate || 0) : 0));
        if (group[0])
            out.push(group[0]);
    }
    return out;
}
function visitMedia(capture, selected, fn, quotes = true) {
    const seen = new Set();
    let budget = 2000;
    const visit = (p, depth) => {
        if (depth > 8 || seen.has(p) || budget-- <= 0)
            return;
        seen.add(p);
        let i = 0;
        for (const b of p.blocks) {
            if (b.kind === 'media') {
                b.media.ownerId = p.id;
                b.media.scopeId = `${p.id}:${b.media.mediaRole || 'body'}:${sameMediaKey(b.media) || i}`;
                fn(b.media, p);
                i++;
            }
            else if (b.kind === 'embed' && quotes)
                visit(b.post, depth + 1);
        }
        if (p.linkCard?.media) {
            const m = p.linkCard.media;
            m.ownerId = p.id;
            m.scopeId = `${p.id}:card:${sameMediaKey(m) || 'visible'}`;
            fn(m, p);
        }
        if (p.quote && quotes)
            visit(p.quote, depth + 1);
    };
    for (const p of capture.posts)
        if (selected.has(p.id))
            visit(p, 0);
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.safeResourceRequest = safeResourceRequest;
exports.nativeResource = nativeResource;
exports.decodeImageDimensions = decodeImageDimensions;
const resources_1 = __require(3);
function safeResourceRequest(raw) {
    if (!raw || !(0, resources_1.fetchableResource)(raw.url) || !['image', 'manifest', 'headers'].includes(raw.purpose))
        return;
    const limit = raw.purpose === 'image' ? 8 * 1024 * 1024 : raw.purpose === 'manifest' ? 524288 : 65536;
    return { url: raw.url, purpose: raw.purpose, maxBytes: Math.max(1, Math.min(limit, Number(raw.maxBytes) || limit)), timeoutMs: Math.max(500, Math.min(10000, Number(raw.timeoutMs) || 6000)) };
}
/** No GM bridge is used for new resource validation: older Stay bridges do not
 * document redirect rejection reliably. Native fetch fails closed on CORS/redirect.
 * DOM-discovered addresses remain available even when validation is impossible. */
async function nativeResource(raw, signal) {
    const request = safeResourceRequest(raw);
    const empty = new Uint8Array();
    if (!request)
        return { status: 0, url: '', mime: '', bytes: empty, problem: 'domain-blocked' };
    const ctrl = new AbortController();
    let timed = false;
    const stop = () => ctrl.abort();
    if (signal?.aborted)
        stop();
    else
        signal?.addEventListener('abort', stop, { once: true });
    const timer = setTimeout(() => { timed = true; ctrl.abort(); }, request.timeoutMs);
    const requestInit = { credentials: 'omit', referrerPolicy: 'no-referrer', redirect: 'error', cache: 'no-store', signal: ctrl.signal };
    try {
        let response = await fetch(request.url, { ...requestInit, method: request.purpose === 'headers' ? 'HEAD' : 'GET' });
        // A rejected HEAD is not proof a GET resource is unavailable. Bound the fallback.
        if (request.purpose === 'headers' && [405, 501].includes(response.status))
            response = await fetch(request.url, { ...requestInit, method: 'GET', headers: { Range: 'bytes=0-65535' } });
        if (response.redirected || response.url && response.url !== request.url) {
            await response.body?.cancel();
            return { status: response.status, url: request.url, mime: '', bytes: empty, problem: 'redirect-blocked' };
        }
        const mime = response.headers.get('content-type') || '', size = Number(response.headers.get('content-length'));
        if (!response.ok) {
            await response.body?.cancel();
            return { status: response.status, url: request.url, mime, bytes: empty, problem: response.status === 404 || response.status === 410 ? 'not-found' : response.status === 401 || response.status === 403 ? 'forbidden' : response.status === 429 ? 'rate-limit' : 'http-error' };
        }
        if (request.purpose === 'headers') {
            await response.body?.cancel();
            return { status: response.status, url: request.url, mime, bytes: empty };
        }
        if (size > request.maxBytes) {
            await response.body?.cancel();
            return { status: response.status, url: request.url, mime, bytes: empty, problem: 'too-large' };
        }
        if (!response.body) {
            return { status: response.status, url: request.url, mime, bytes: empty, problem: 'unsupported' };
        }
        const reader = response.body.getReader(), chunks = [];
        let received = 0;
        while (true) {
            const { value, done } = await reader.read();
            if (done)
                break;
            received += value.length;
            if (received > request.maxBytes) {
                await reader.cancel();
                return { status: response.status, url: request.url, mime, bytes: empty, problem: 'too-large' };
            }
            chunks.push(value);
        }
        const bytes = new Uint8Array(received);
        let offset = 0;
        for (const part of chunks) {
            bytes.set(part, offset);
            offset += part.length;
        }
        return { status: response.status, url: request.url, mime, bytes };
    }
    catch {
        return { status: 0, url: request.url, mime: '', bytes: empty, problem: timed ? 'timeout' : signal?.aborted ? 'cancelled' : 'network-or-cors' };
    }
    finally {
        clearTimeout(timer);
        signal?.removeEventListener('abort', stop);
    }
}
async function decodeImageDimensions(bytes, mime) {
    const a = bytes;
    let type = '';
    if (a[0] === 0xff && a[1] === 0xd8)
        type = 'image/jpeg';
    else if (a.length > 24 && a[0] === 137 && a[1] === 80 && a[2] === 78 && a[3] === 71)
        type = 'image/png';
    else if (a.length > 10 && String.fromCharCode(...a.slice(0, 3)) === 'GIF')
        type = 'image/gif';
    else if (a.length > 16 && String.fromCharCode(...a.slice(0, 4)) === 'RIFF' && String.fromCharCode(...a.slice(8, 12)) === 'WEBP')
        type = 'image/webp';
    else if (a.length > 16 && String.fromCharCode(...a.slice(4, 8)) === 'ftyp' && /avif|avis/.test(String.fromCharCode(...a.slice(8, 32))))
        type = 'image/avif';
    if (!type)
        throw new Error('Not a supported bitmap');
    const blob = new Blob([bytes], { type });
    const check = (w, h) => { if (!w || !h || w * h > 80000000)
        throw new Error('Image pixel budget'); return { width: w, height: h }; };
    // Do not instantiate an enormous bitmap if its header already reveals its dimensions.
    if (type === 'image/png') {
        const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        check(v.getUint32(16), v.getUint32(20));
    }
    if (type === 'image/gif')
        check(a[6] + a[7] * 256, a[8] + a[9] * 256);
    if (type === 'image/jpeg') {
        let offset = 2;
        while (offset + 8 < a.length) {
            if (a[offset] !== 255) {
                offset++;
                continue;
            }
            while (a[offset] === 255)
                offset++;
            const marker = a[offset++];
            if (marker === 217 || marker === 218)
                break;
            if (marker === 1 || marker >= 208 && marker <= 215)
                continue;
            const length = a[offset] * 256 + a[offset + 1];
            if (length < 2 || offset + length > a.length)
                break;
            if ([192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207].includes(marker)) {
                check(a[offset + 5] * 256 + a[offset + 6], a[offset + 3] * 256 + a[offset + 4]);
                break;
            }
            offset += length;
        }
    }
    if (type === 'image/webp') {
        const v = new DataView(a.buffer, a.byteOffset, a.byteLength);
        let at = 12;
        while (at + 8 <= a.length) {
            const kind = String.fromCharCode(...a.slice(at, at + 4)), length = v.getUint32(at + 4, true), start = at + 8;
            if (start + length > a.length)
                break;
            if (kind === 'VP8X' && length >= 10)
                check(1 + a[start + 4] + 256 * a[start + 5] + 65536 * a[start + 6], 1 + a[start + 7] + 256 * a[start + 8] + 65536 * a[start + 9]);
            if (kind === 'VP8L' && length >= 5 && a[start] === 47) {
                const bits = v.getUint32(start + 1, true);
                check(1 + (bits & 16383), 1 + ((bits >>> 14) & 16383));
            }
            if (kind === 'VP8 ' && length >= 10 && a[start + 3] === 157 && a[start + 4] === 1 && a[start + 5] === 42)
                check(v.getUint16(start + 6, true) & 16383, v.getUint16(start + 8, true) & 16383);
            at = start + length + (length % 2);
        }
    }
    if (type === 'image/avif') {
        // ispe dimensions occur inside a bounded ISO-BMFF property box. Inspect only valid box sizes.
        const v = new DataView(a.buffer, a.byteOffset, a.byteLength);
        for (let at = 4; at + 16 < a.length; at++)
            if (a[at] === 105 && a[at + 1] === 115 && a[at + 2] === 112 && a[at + 3] === 101) {
                const size = v.getUint32(at - 4);
                if (size >= 20 && at - 4 + size <= a.length)
                    check(v.getUint32(at + 8), v.getUint32(at + 12));
            }
    }
    if (typeof createImageBitmap === 'function') {
        let bitmap;
        try {
            bitmap = await createImageBitmap(blob);
            return check(bitmap.width, bitmap.height);
        }
        finally {
            bitmap?.close();
        }
    }
    const url = URL.createObjectURL(blob);
    try {
        return await new Promise((resolve, reject) => { const im = new Image(), timer = setTimeout(() => { im.src = ''; reject(new Error('Image decode timeout')); }, 7000); im.onload = () => { clearTimeout(timer); try {
            resolve(check(im.naturalWidth, im.naturalHeight));
        }
        catch (e) {
            reject(e);
        } }; im.onerror = () => { clearTimeout(timer); reject(new Error('Image decode failed')); }; im.src = url; });
    }
    finally {
        URL.revokeObjectURL(url);
    }
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sourceURL = sourceURL;
exports.postID = postID;
exports.safeLink = safeLink;
exports.allowedAsset = allowedAsset;
exports.plainText = plainText;
exports.contextText = contextText;
function sourceURL(value, base = 'https://x.com/') {
    try {
        const u = new URL(value, base);
        if (!['https:', 'http:'].includes(u.protocol))
            return;
        if (!/^(?:www\.|mobile\.)?(?:x\.com|twitter\.com)$/.test(u.hostname))
            return;
        const m = u.pathname.match(/^\/(?:([\w]+)\/status\/(\d+)|i\/article\/(\d+)|i\/web\/status\/(\d+))(?=\/|$)/);
        if (!m)
            return;
        return `https://x.com${m[3] ? '/i/article/' + m[3] : m[4] ? '/i/web/status/' + m[4] : '/' + m[1] + '/status/' + m[2]}`;
    }
    catch {
        return;
    }
}
function postID(url) { return url.match(/\/(?:status|article)\/(\d+)/)?.[1]; }
function safeLink(value, base = 'https://x.com/') {
    try {
        const u = new URL(value, base);
        return ['https:', 'http:'].includes(u.protocol) ? u.href : undefined;
    }
    catch {
        return;
    }
}
function allowedAsset(url) {
    try {
        const u = new URL(url);
        return u.protocol === 'https:' && !u.username && !u.password && (!u.port || u.port === '443') && (/^([a-z\d-]+\.)*twimg\.com$/.test(u.hostname) || u.href === 'https://raw.githubusercontent.com/notofonts/noto-cjk/Sans2.004/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf');
    }
    catch {
        return false;
    }
}
function plainText(p) { return p.blocks.map(b => b.kind === 'text' ? b.runs.map((r) => r.text).join('') : b.kind === 'media' ? `[${b.media.kind}: ${b.media.alt || '媒体'}]` : b.kind === 'embed' ? `[嵌入帖子]\n${plainText(b.post)}` : '').join('\n'); }
/** Copy the selected contextual record without pretending hidden fields were captured. */
function contextText(p, identity = true, sources = true, depth = 0) {
    if (depth > 5)
        return '[更深层引用未展开]';
    const out = [identity ? `${p.author.name} @${p.author.handle}` : '匿名用户'];
    if (p.title)
        out.push(p.title);
    if (p.published || p.displayTime)
        out.push(p.published || p.displayTime);
    out.push(plainText(p));
    if (p.quote)
        out.push('引用帖子：\n' + contextText(p.quote, identity, sources, depth + 1));
    if (p.poll)
        out.push('投票：\n' + p.poll.options.map((v) => v.text + (v.percent === undefined ? '' : ` ${v.percent}%`)).join('\n') + '\n' + (p.poll.summary || ''));
    if (p.note)
        out.push('读者补充背景：' + p.note);
    if (p.linkCard)
        out.push('链接卡片：' + p.linkCard.title + (sources ? '\n' + p.linkCard.url : ''));
    if (sources)
        out.push('来源：' + p.url);
    return out.filter(Boolean).join('\n');
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.utf8 = void 0;
exports.concat = concat;
exports.base64 = base64;
exports.unbase64 = unbase64;
exports.compress = compress;
exports.xml = xml;
exports.utf16Hex = utf16Hex;
const utf8 = (value) => new TextEncoder().encode(value);
exports.utf8 = utf8;
function concat(parts) { const out = new Uint8Array(parts.reduce((n, p) => n + p.byteLength, 0)); let o = 0; for (const p of parts) {
    out.set(p, o);
    o += p.byteLength;
} return out; }
function base64(bytes) { let value = ''; for (let i = 0; i < bytes.length; i += 24576)
    value += String.fromCharCode(...bytes.subarray(i, i + 24576)); return btoa(value); }
function unbase64(value) { const str = atob(value), out = new Uint8Array(str.length); for (let i = 0; i < str.length; i++)
    out[i] = str.charCodeAt(i); return out; }
async function compress(bytes) {
    if (typeof CompressionStream === 'undefined')
        return { data: bytes, filter: '' };
    try {
        const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate'));
        return { data: new Uint8Array(await new Response(stream).arrayBuffer()), filter: '/Filter /FlateDecode' };
    }
    catch {
        return { data: bytes, filter: '' };
    }
}
function xml(value) { return value.replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c])); }
function utf16Hex(value, bom = true) { let out = bom ? 'FEFF' : ''; for (let i = 0; i < value.length; i++)
    out += value.charCodeAt(i).toString(16).padStart(4, '0'); return out; }

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pageProbe = pageProbe;
/** Best-effort, read-only access to already-present page render data. No API calls,
 * cookie reads, credentials, hidden endpoint requests or account automation.
 * Function is self-contained because Chromium executes it in MAIN world. */
function pageProbe(ids, suppliedWindow) {
    const win = suppliedWindow || window, wanted = new Set(ids.slice(0, 250));
    const found = new Map();
    // Self-contained for MAIN-world execution. Read only variants already present
    // in the page; do not call an X endpoint or request video bytes.
    const publicMedia = (subject, href) => {
        const valid = (s) => {
            if (typeof s !== 'string' || s.length > 12000 || !/^https?:\/\//i.test(s) || /[\u0000-\u0020\u007f]/.test(s))
                return;
            try {
                const u = new URL(s);
                if (u.username || u.password || u.port || !/(^|\.)twimg\.com$/i.test(u.hostname))
                    return;
                return u.href;
            }
            catch {
                return;
            }
        };
        const finite = (v) => Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : undefined;
        const string = (v) => typeof v === 'string' ? v.replace(/[\u0000-\u001f]/g, '').slice(0, 240) : undefined;
        const legacy = subject?.legacy || subject;
        let raw = legacy?.extended_entities?.media || subject?.media_entities || subject?.article?.media_entities || subject?.article_results?.result?.media_entities || [];
        // API-v2-shaped data is accepted only when explicitly attached to this same object.
        if (!raw.length && Array.isArray(subject?.attachments?.media_keys) && Array.isArray(subject?.includes?.media))
            raw = subject.includes.media.filter((m) => subject.attachments.media_keys.includes(m.media_key));
        if (!Array.isArray(raw))
            raw = [];
        return raw.slice(0, 64).filter((m) => m && typeof m === 'object').map((m, index) => {
            const info = m.media_info || m, video = info.video_info || m.video_info || info;
            const type = info.type || m.type || info.__typename;
            const kind = type === 'photo' || type === 'image' || /Image/.test(type) ? 'image' : type === 'animated_gif' ? 'gif' : 'video';
            const src = valid(m.media_url_https) || valid(info.original_img_url) || valid(info.media_url_https) || valid(info.preview_image_url) || valid(m.preview_image_url) || (kind === 'image' ? valid(info.url) : undefined) || '';
            const width = finite(info.original_info?.width || info.width), height = finite(info.original_info?.height || info.height);
            const variants = (Array.isArray(video.variants) ? video.variants : Array.isArray(info.variants) ? info.variants : []).slice(0, 128).map((v) => {
                const url = valid(v?.url);
                if (!url)
                    return;
                const mime = string(v.content_type || v.mime_type || v.mime);
                const path = new URL(url).pathname, ext = path.match(/\.(\w+)$/)?.[1]?.toLowerCase();
                const k = /mpegurl/i.test(mime || '') || ext === 'm3u8' ? 'hls' : mime?.split(';')[0].toLowerCase() === 'application/dash+xml' || ext === 'mpd' ? 'dash' : /video\//i.test(mime || '') || ['mp4', 'm4v', 'mov', 'webm', 'ogv', 'ogg'].includes(ext || '') ? 'file' : undefined;
                if (!k)
                    return;
                const size = path.match(/\/vid\/(?:[a-z0-9.]+\/)?(\d+)x(\d+)\//i);
                return { url, kind: k, mime, width: finite(v.width) || finite(size?.[1]), height: finite(v.height) || finite(size?.[2]), bitrate: finite(v.bitrate ?? v.bit_rate), codecs: string(v.codecs), frameRate: finite(v.frame_rate), state: 'observed', source: 'page-data' };
            }).filter(Boolean);
            if (kind === 'image' && src)
                variants.push({ url: src, kind: 'image', width, height, state: 'observed', source: 'page-data' });
            const list = video.subtitles || info.subtitles || video.subtitle_info?.subtitles || info.subtitle_info?.subtitles || [];
            const tracks = (Array.isArray(list) ? list : []).slice(0, 64).map((t, i) => {
                const url = valid(t?.url || t?.src);
                const language = string(t?.language || t?.language_code || t?.lang);
                if (!url && !language)
                    return;
                return { id: string(t.id) || 'data-sub-' + i, kind: 'subtitles', url, language, label: string(t.label || t.name), mime: string(t.content_type), default: t.default === true, forced: t.forced === true, inBand: !url, state: 'observed', source: 'page-data' };
            }).filter(Boolean);
            const mediaId = string(m.media_key || m.id_str || m.media_id || m.rest_id || m.media_id_str || info.id);
            return { mediaId, src, kind, alt: string(m.ext_alt_text || info.alt_text) || '引用帖媒体', href, attachmentIndex: index + 1, variants, tracks,
                ...(kind !== 'image' ? { posterUrl: src, sourceUrl: variants.filter((v) => v.kind === 'file').sort((a, b) => (b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0) || ((a.codecs || '') === (b.codecs || '') ? (b.bitrate || 0) - (a.bitrate || 0) : 0))[0]?.url || variants[0]?.url, playbackUrl: typeof m.expanded_url === 'string' ? m.expanded_url : undefined } : { sourceUrl: src }) };
        });
    };
    const cardMedia = (subject, href) => {
        const values = subject?.card?.legacy?.binding_values || subject?.card?.binding_values || [];
        const entries = Array.isArray(values) ? values : Object.entries(values).map(([key, value]) => ({ key, value }));
        const byKey = {};
        for (const item of entries.slice(0, 80))
            if (item && typeof item.key === 'string' && /^(?:amplify_url_vmap|player_stream_url|player_url|video_url|player_image|thumbnail_image)$/.test(item.key))
                byKey[item.key] = item.value;
        const vars = [];
        for (const k of ['amplify_url_vmap', 'player_stream_url', 'video_url']) {
            const url = byKey[k]?.string_value;
            if (typeof url === 'string' && /^https:\/\/(?:video|pbs)\.twimg\.com\//.test(url))
                vars.push({ url, kind: k === 'amplify_url_vmap' ? 'vmap' : /\.m3u8(?:\?|$)/.test(url) ? 'hls' : /\.mpd(?:\?|$)/.test(url) ? 'dash' : 'file', source: 'page-data', state: 'observed' });
        }
        const src = byKey.player_image?.image_value?.url || byKey.thumbnail_image?.image_value?.url;
        return vars.length && typeof src === 'string' ? [{ kind: 'video', src, posterUrl: src, href, variants: vars, alt: '嵌入视频' }] : [];
    };
    const publicQuote = (item, depth = 0) => {
        if (depth > 3 || !item || typeof item !== 'object')
            return;
        const q = item.tweet || item, legacy = q.legacy || q, id = String(q.rest_id || legacy.id_str || '');
        if (!/^\d+$/.test(id))
            return;
        const user = q.core?.user_results?.result || q.user, userLegacy = user?.legacy || user || {}, name = user?.core?.name || userLegacy.name, handle = user?.core?.screen_name || userLegacy.screen_name;
        const fullText = q.note_tweet?.note_tweet_results?.result?.text || q.note_tweet?.text || legacy.full_text;
        const result = { id, url: /^[A-Za-z0-9_]+$/.test(handle || '') ? `https://x.com/${handle}/status/${id}` : `https://x.com/i/web/status/${id}` };
        if (typeof name === 'string' && typeof handle === 'string')
            result.author = { name: name.slice(0, 200), handle: handle.slice(0, 40), avatar: user?.avatar?.image_url || userLegacy.profile_image_url_https, verified: !!(user?.is_blue_verified || userLegacy.verified) };
        if (typeof fullText === 'string')
            result.fullText = fullText.slice(0, 400000);
        const date = new Date(legacy.created_at);
        if (!isNaN(+date))
            result.published = date.toISOString();
        result.media = publicMedia(q, result.url);
        const nested = publicQuote(q.quoted_status_result?.result || q.quoted_status, depth + 1);
        if (nested)
            result.quote = nested;
        return result;
    };
    // Logged-out desktop X (2026-10) renders through Relay: props hold fragment references and the
    // resolved data lives in fragment hook snapshots under the <article>. Every value is attributed by
    // its own record ID (base64 "Tweet:<id>", media "client:<that>:media_entities2:<n>"), never by position.
    const relayTweet = (v) => {
        if (typeof v !== 'string' || v.length > 400)
            return;
        const m = v.match(/^(?:client:)?([A-Za-z0-9+/]{8,}=*)(?::|$)/);
        if (!m)
            return;
        try {
            return atob(m[1]).match(/^Tweet:(\d{1,25})$/)?.[1];
        }
        catch {
            return;
        }
    };
    const relayPost = (el) => {
        const fk = Object.keys(el).find(k => k.startsWith('__reactFiber$'));
        let root;
        try {
            root = fk ? el[fk] : undefined;
        }
        catch {
            return;
        }
        const snapshots = [], stack = [[root?.child, 0]];
        let fibers = 0;
        while (stack.length && fibers < 4000) {
            const [f, depth] = stack.pop();
            if (!f || typeof f !== 'object')
                continue;
            fibers++;
            try {
                let hook = f.memoizedState;
                for (let i = 0; hook && typeof hook === 'object' && i < 48; i++, hook = hook.next) {
                    const v = hook.memoizedState;
                    if (!v || typeof v !== 'object')
                        continue;
                    if (v.snapshot?.data && typeof v.snapshot.data === 'object')
                        snapshots.push(v.snapshot.data);
                    if (Array.isArray(v.snapshots))
                        for (const x of v.snapshots.slice(0, 16))
                            if (x?.data && typeof x.data === 'object')
                                snapshots.push(x.data);
                }
                if (f.sibling)
                    stack.push([f.sibling, depth]);
                if (f.child && depth < 120)
                    stack.push([f.child, depth + 1]);
            }
            catch { }
        }
        const records = new Map(), record = (id) => { let r = records.get(id); if (!r)
            records.set(id, r = { media: [] }); return r; };
        const seen = new WeakSet();
        let budget = 20000;
        const visit = (o, tweet, index, depth) => {
            var _a;
            if (!o || typeof o !== 'object' || seen.has(o) || depth > 9 || budget-- <= 0 || (win.Node && o instanceof win.Node))
                return;
            seen.add(o);
            try {
                if (typeof o.__id === 'string') {
                    tweet = relayTweet(o.__id);
                    const n = o.__id.match(/:media_entities2:(\d{1,2})$/);
                    index = n ? Number(n[1]) : -1;
                }
                // Some fragments select rest_id without __id; `details` exists only on tweet records (users have rest_id too).
                else if (typeof o.rest_id === 'string' && /^\d+$/.test(o.rest_id) && o.details && typeof o.details === 'object') {
                    tweet = o.rest_id;
                    index = -1;
                }
                if (tweet && index >= 0) {
                    const m = (_a = record(tweet).media)[index] || (_a[index] = {});
                    for (const k of ['media_url_https', 'type', 'id_str', 'media_key', 'ext_alt_text', 'original_info', 'video_download_url', 'video_info'])
                        if (o[k] != null && m[k] === undefined)
                            m[k] = o[k];
                }
                else if (tweet) {
                    const r = record(tweet), d = o.details;
                    const text = o.note_tweet?.note_tweet_results?.result?.text ?? d?.full_text;
                    if (typeof text === 'string' && r.fullText === undefined)
                        r.fullText = text;
                    if (Number.isFinite(d?.created_at_ms) && !r.published)
                        r.published = new Date(d.created_at_ms).toISOString();
                    const parent = o.reply_to_results?.rest_id;
                    if (typeof parent === 'string' && /^\d+$/.test(parent) && parent !== tweet)
                        r.parentId = parent;
                }
            }
            catch {
                return;
            }
            let keys;
            try {
                keys = Object.keys(o);
            }
            catch {
                return;
            }
            for (const k of keys) {
                if (k === '__fragmentOwner' || /token|cookie|session|auth|password/i.test(k))
                    continue;
                let v;
                try {
                    v = o[k];
                }
                catch {
                    continue;
                }
                if (!v || typeof v !== 'object')
                    continue;
                if (k === 'media_entities2' && Array.isArray(v))
                    v.slice(0, 64).forEach((x, i) => visit(x, tweet, i, depth + 1));
                else
                    visit(v, tweet, index, depth + 1);
            }
        };
        for (const data of snapshots)
            visit(data, undefined, -1, 0);
        for (const [id, r] of records) {
            if (!wanted.has(id) || found.has(id))
                continue;
            const media = r.media.filter(Boolean).map((m) => {
                const info = m.video_info && typeof m.video_info === 'object' ? m.video_info : undefined, variants = Array.isArray(info?.variants) ? info.variants.slice(0, 127) : [];
                // The largest progressive MP4 is often only in video_download_url, not in variants.
                if (info && typeof m.video_download_url === 'string' && !variants.some((v) => v?.url === m.video_download_url))
                    variants.push({ content_type: 'video/mp4', url: m.video_download_url });
                const type = typeof m.type === 'string' ? m.type : info ? (variants.some((v) => /\/tweet_video\//.test(v?.url || '')) ? 'animated_gif' : 'video') : 'photo';
                return { ...m, type, video_info: info ? { ...info, variants } : undefined };
            });
            const data = { id, relationEvidence: 'data', media: publicMedia({ extended_entities: { media } }, `https://x.com/i/web/status/${id}`) };
            if (r.parentId)
                data.parentId = r.parentId;
            if (r.published)
                data.published = r.published;
            if (typeof r.fullText === 'string' && r.fullText.length < 400000)
                data.fullText = r.fullText;
            found.set(id, data);
        }
    };
    const nodes = [...win.document.querySelectorAll('article[data-testid="tweet"], [data-testid="twitterArticleReadView"], [data-testid="twitterArticleRichTextView"], article:not([data-testid])')];
    for (const el of nodes) {
        if (el.tagName === 'ARTICLE' && !el.hasAttribute('data-testid')) {
            relayPost(el);
            continue;
        }
        const own = Object.keys(el).filter(k => k.startsWith('__reactFiber$') || k.startsWith('__reactProps$'));
        if (!own.length)
            continue;
        const queue = [], seen = new WeakSet();
        let budget = 3200;
        // Desktop X (2026) passes a flattened tweet as a prop of an ANCESTOR component.
        // Read only those ancestors' props, shallowly; results stay keyed by wanted post IDs.
        const fiberKey = own.find(k => k.startsWith('__reactFiber$'));
        let fiber;
        try {
            fiber = fiberKey ? el[fiberKey]?.return : undefined;
        }
        catch {
            fiber = undefined;
        }
        for (let hop = 0; fiber && hop < 16; hop++) {
            let props;
            try {
                props = fiber.memoizedProps;
                fiber = fiber.return;
            }
            catch {
                break;
            }
            if (props && typeof props === 'object')
                queue.push([props, 5]);
        }
        for (const k of own)
            queue.push([el[k], 0]);
        while (queue.length && budget-- > 0) {
            const [obj, depth] = queue.shift();
            if (!obj || typeof obj !== 'object' || seen.has(obj))
                continue;
            seen.add(obj);
            let id;
            try {
                id = String(obj.rest_id || obj.id_str || obj.legacy?.id_str || obj.id || '');
            }
            catch {
                continue;
            }
            const flat = !obj.legacy && typeof obj.id_str === 'string' && (obj.full_text !== undefined || obj.extended_entities);
            if (id && wanted.has(id) && !found.has(id) && (obj.legacy && (obj.legacy.full_text !== undefined || obj.note_tweet) || flat || obj.media_entities || obj.article?.media_entities || obj.article_results?.result?.media_entities || obj.attachments?.media_keys)) {
                const l = obj.legacy || (flat ? obj : {}), n = obj.note_tweet?.note_tweet_results?.result || (typeof obj.note_tweet?.text === 'string' ? obj.note_tweet : undefined);
                const text = typeof n?.text === 'string' ? n.text : typeof l.full_text === 'string' ? l.full_text : undefined;
                const data = { id, relationEvidence: 'data', media: [...publicMedia(obj, `https://x.com/i/web/status/${id}`), ...cardMedia(obj, `https://x.com/i/web/status/${id}`)] };
                if (/^\d+$/.test(l.in_reply_to_status_id_str || ''))
                    data.parentId = l.in_reply_to_status_id_str;
                if (/^\d+$/.test(l.conversation_id_str || ''))
                    data.conversationId = l.conversation_id_str;
                if (text && text.length < 400000) {
                    // Expanded URLs and exact Unicode text are preferred over shortened t.co text.
                    const entities = n?.entity_set || l.entities || {};
                    let expanded = text;
                    for (const u of entities.urls || [])
                        if (u.url && u.expanded_url)
                            expanded = expanded.split(u.url).join(u.expanded_url);
                    data.fullText = expanded;
                }
                const q = publicQuote(obj.quoted_status_result?.result || (flat ? obj.quoted_status : undefined));
                if (q)
                    data.quote = q;
                if (/^\d+$/.test(l.quoted_status_id_str || ''))
                    data.quotedId = l.quoted_status_id_str;
                found.set(id, data);
            }
            if (depth >= 9)
                continue;
            let keys;
            try {
                keys = Object.keys(obj);
            }
            catch {
                continue;
            }
            for (const k of keys) {
                if (['return', 'stateNode', 'alternate', 'ownerDocument', 'parentNode', '_owner', 'ref', 'updateQueue', 'dependencies'].includes(k))
                    continue;
                if (/token|cookie|session|auth|password/i.test(k))
                    continue;
                try {
                    const val = obj[k];
                    if (val && typeof val === 'object' && !(val instanceof win.Node))
                        queue.push([val, depth + 1]);
                }
                catch { }
            }
        }
    }
    return [...found.values()];
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeBytes = nativeBytes;
exports.createHost = createHost;
const resource_network_1 = __require(4);
const model_1 = __require(9);
const urls_1 = __require(5);
const binary_1 = __require(6);
const probe_1 = __require(7);
async function nativeBytes(url, signal) {
    const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 35000);
    const abort = () => ctrl.abort();
    signal?.addEventListener('abort', abort, { once: true });
    try {
        const r = await fetch(url, { signal: ctrl.signal, credentials: 'omit', referrerPolicy: 'no-referrer', redirect: 'error' });
        if (!r.ok)
            throw new Error(`资源请求失败 (${r.status})`);
        const max = url === model_1.FONT_URL ? 28 * 1024 * 1024 : 20 * 1024 * 1024;
        if (Number(r.headers.get('content-length')) > max)
            throw new Error('资源超过安全大小限制。');
        if (!r.body) {
            const b = new Uint8Array(await r.arrayBuffer());
            if (b.length > max)
                throw new Error('资源过大。');
            return b;
        }
        const reader = r.body.getReader(), chunks = [];
        let size = 0;
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            size += value.byteLength;
            if (size > max) {
                await reader.cancel();
                throw new Error('资源超过安全大小限制。');
            }
            chunks.push(value);
        }
        const bytes = new Uint8Array(size);
        let p = 0;
        for (const c of chunks) {
            bytes.set(c, p);
            p += c.length;
        }
        return bytes;
    }
    finally {
        clearTimeout(timer);
        signal?.removeEventListener('abort', abort);
    }
}
function gmRequest(url, signal) {
    return new Promise((resolve, reject) => {
        const modern = typeof GM !== 'undefined' ? GM : undefined;
        const send = typeof GM_xmlhttpRequest === 'function' ? GM_xmlhttpRequest : modern?.xmlHttpRequest;
        if (!send) {
            reject(new Error('脚本管理器未提供 GM_xmlhttpRequest。'));
            return;
        }
        let request, ended = false;
        const finish = (error, b) => { if (ended)
            return; ended = true; signal?.removeEventListener('abort', cancel); error ? reject(error) : resolve(b); };
        const cancel = () => { try {
            request?.abort();
        }
        catch { } finish(new DOMException('已取消', 'AbortError')); };
        if (signal?.aborted) {
            cancel();
            return;
        }
        signal?.addEventListener('abort', cancel, { once: true });
        request = send({ url, method: 'GET', anonymous: true, responseType: 'arraybuffer', timeout: 35000, onload: async (r) => {
                try {
                    if (r.status < 200 || r.status >= 300)
                        throw new Error(`资源请求失败 (${r.status})`);
                    let b;
                    if (r.response instanceof ArrayBuffer)
                        b = new Uint8Array(r.response);
                    else if (ArrayBuffer.isView(r.response))
                        b = new Uint8Array(r.response.buffer, r.response.byteOffset, r.response.byteLength);
                    else if (r.response instanceof Blob)
                        b = new Uint8Array(await r.response.arrayBuffer());
                    else
                        throw new Error('Stay 返回的二进制资源格式不受支持。');
                    if (b.length > (url === model_1.FONT_URL ? 28 : 20) * 1024 * 1024)
                        throw new Error('资源超过安全大小限制。');
                    finish(undefined, b);
                }
                catch (e) {
                    finish(e);
                }
            }, onerror: () => finish(new Error('资源加载失败，请检查网络或 Stay 的站点权限。')), ontimeout: () => finish(new Error('资源加载超时。')), onabort: cancel });
    });
}
/** A stalled mobile bridge must not prevent the studio from appearing. */
function storageRead(read, fallback) {
    return new Promise(resolve => {
        let done = false;
        const finish = (v) => { if (done)
            return; done = true; clearTimeout(timer); resolve(v); };
        const timer = setTimeout(() => finish(fallback), 2000);
        try {
            Promise.resolve(read()).then(v => finish(v === undefined ? fallback : v), () => finish(fallback));
        }
        catch {
            finish(fallback);
        }
    });
}
function createHost(kind) {
    if (kind === 'extension')
        return { kind,
            async observe(action, sessionId) { try {
                return await chrome.runtime.sendMessage({ type: 'xc:observe', action, sessionId }) || { state: 'unavailable', records: [] };
            }
            catch {
                return { state: 'unavailable', records: [] };
            } },
            async openObservationPermission() { try {
                return !!(await chrome.runtime.sendMessage({ type: 'xc:observe-enable' }))?.ok;
            }
            catch {
                return false;
            } },
            async getValue(key, fallback) { const v = await chrome.storage.local.get(key); return v[key] ?? fallback; },
            async setValue(key, value) { await chrome.storage.local.set({ [key]: value }); },
            async readBytes(url, signal) {
                if (!(0, urls_1.allowedAsset)(url))
                    throw new Error('资源域名不在允许列表。');
                if (signal?.aborted)
                    throw new DOMException('已取消', 'AbortError');
                const res = await chrome.runtime.sendMessage({ type: 'xc:asset', url });
                if (!res?.ok)
                    throw new Error(res?.error || '资源读取失败。');
                if (signal?.aborted)
                    throw new DOMException('已取消', 'AbortError');
                return (0, binary_1.unbase64)(res.data);
            },
            async readResource(request, signal) {
                const id = typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : Array.from(crypto.getRandomValues(new Uint32Array(4)), v => v.toString(16)).join('-');
                const cancel = () => { void chrome.runtime.sendMessage({ type: 'xc:resource-cancel', requestId: id }).catch(() => { }); };
                if (signal?.aborted)
                    return { status: 0, url: request.url, mime: '', bytes: new Uint8Array(), problem: 'cancelled' };
                signal?.addEventListener('abort', cancel, { once: true });
                try {
                    const r = await chrome.runtime.sendMessage({ type: 'xc:resource', requestId: id, request });
                    if (signal?.aborted)
                        return { status: 0, url: request.url, mime: '', bytes: new Uint8Array(), problem: 'cancelled' };
                    if (!r?.ok)
                        return { status: 0, url: request.url, mime: '', bytes: new Uint8Array(), problem: 'network-or-cors' };
                    return { ...r.response, bytes: (0, binary_1.unbase64)(r.data || '') };
                }
                finally {
                    signal?.removeEventListener('abort', cancel);
                }
            },
            async probe(ids) { const r = await chrome.runtime.sendMessage({ type: 'xc:probe', ids }); return r?.data || []; } };
    return { kind,
        async getValue(key, fallback) { try {
            if (kind === 'stay') {
                if (typeof GM_getValue === 'function')
                    return await storageRead(() => GM_getValue(key, fallback), fallback);
                if (typeof GM !== 'undefined' && GM.getValue)
                    return await storageRead(() => GM.getValue(key, fallback), fallback);
            }
            const v = localStorage.getItem('xc:' + key);
            return v ? JSON.parse(v) : fallback;
        }
        catch {
            return fallback;
        } },
        async setValue(key, value) { if (kind === 'stay') {
            if (typeof GM_setValue === 'function') {
                await GM_setValue(key, value);
                return;
            }
            if (typeof GM !== 'undefined' && GM.setValue) {
                await GM.setValue(key, value);
                return;
            }
        } localStorage.setItem('xc:' + key, JSON.stringify(value)); },
        async readBytes(url, signal) { if (!(0, urls_1.allowedAsset)(url))
            throw new Error('资源域名不在允许列表。'); if (kind === 'stay') {
            try {
                return await gmRequest(url, signal);
            }
            catch (e) {
                if (signal?.aborted)
                    throw e;
                return nativeBytes(url, signal);
            }
        } return nativeBytes(url, signal); },
        readResource: resource_network_1.nativeResource,
        async probe(ids) { return (0, probe_1.pageProbe)(ids, window); } };
}

},
function(module,exports,__require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FONT_CACHE_KEY = exports.FONT_URL = exports.VERSION = void 0;
/** Captured facts are separate from selection, style and inferred relationships. */
exports.VERSION = '1.0.0-rc.8';
exports.FONT_URL = 'https://raw.githubusercontent.com/notofonts/noto-cjk/Sans2.004/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf';
exports.FONT_CACHE_KEY = 'noto-cjk-sc-Sans2.004';

}];const cache={};function requireModule(id){if(cache[id])return cache[id].exports;const m=cache[id]={exports:{}};modules[id](m,m.exports,requireModule);return m.exports;}return requireModule(0);})();
